#include <utility>
#include <iostream>
#include <stdexcept>
#include <string>
#include <memory>
#include <vector>
class ClaimError : public std::runtime_error { public: using std::runtime_error::runtime_error; };
void validate(double amount) {
    if (amount < 0) throw std::invalid_argument("negative");
    if (amount > 1e6) throw std::out_of_range("too large");
    std::cout << "ok ";
}
void process(double amount) {
    try { validate(amount); }
    catch (const std::out_of_range& e) { std::cout << "[log " << e.what() << "] "; throw; }
}
double approve(double billed, double cover) {
    if (billed < 0 || cover < 0) throw std::invalid_argument("negative amount");
    if (billed > cover) throw ClaimError("exceeds cover");
    return billed;
}
double settle(double billed, double cover) {
    try { return approve(billed, cover); }
    catch (const ClaimError& e) { std::cout << "audit: " << e.what() << '\n'; throw; }
}
struct ResourceGuard { std::string label; explicit ResourceGuard(std::string s):label(std::move(s)){} ~ResourceGuard(){std::cout<<"released "<<label<<'\n';} };
int main() {
    for (double a : {100.0, -5.0, 2e6}) {
        try { process(a); std::cout << "done "; }
        catch (const std::exception& e) { std::cout << "caught " << e.what() << ' '; }
    }
    std::cout << '\n';
    for (auto pair : {std::pair<double,double>{40000,50000}, {60000,50000}, {-1,50000}}) {
        try { double paid = settle(pair.first,pair.second); std::cout << "approved " << paid << '\n'; }
        catch (const ClaimError& e) { std::cout << "claim rejected: " << e.what() << '\n'; }
        catch (const std::exception& e) { std::cout << "error: " << e.what() << '\n'; }
    }
    try { ResourceGuard g("top-level scope"); throw std::runtime_error("demo"); }
    catch (...) { std::cout << "top-level recovered\n"; }
    try { throw std::bad_alloc(); }
    catch (const std::bad_alloc& e) { std::cout << "allocation failed safely\n"; }
    catch (const std::exception& e) { std::cout << "allocation request rejected: " << e.what() << '\n'; }
}
