#include <algorithm>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <stdexcept>

class Bill {
protected:
    std::string patient;
public:
    explicit Bill(const std::string& p) : patient(p) {}
    virtual ~Bill() = default;
    virtual double total() const = 0;
    virtual std::string type() const { return "Bill"; }
    virtual void print() const { std::cout << type() << ' ' << patient << ": " << total() << '\n'; }
};
class OutPatient : public Bill {
    double consultation, tests;
public:
    OutPatient(const std::string& p, double c, double t) : Bill(p), consultation(c), tests(t) {}
    double total() const override { return consultation + tests; }
    std::string type() const override { return "OP"; }
};
class InPatient : public Bill {
    int days; double perDay, surgery;
public:
    InPatient(const std::string& p, int d, double rate, double s) : Bill(p), days(d), perDay(rate), surgery(s) {}
    double total() const override { return days * perDay + surgery; }
    std::string type() const override { return "IP"; }
};
class DayCare : public Bill {
    double packagePrice;
public:
    DayCare(const std::string& p, double price) : Bill(p), packagePrice(price) {}
    double total() const override { return packagePrice; }
    std::string type() const override { return "DC"; }
};
class Emergency : public Bill {
    double base; int hours; double perHour;
public:
    Emergency(const std::string& p, double b, int h, double rate) : Bill(p), base(b), hours(h), perHour(rate) {}
    double total() const override { return base + hours * perHour; }
    std::string type() const override { return "ER"; }
};
class Payer {
public:
    virtual ~Payer() = default;
    virtual double amountCovered(const Bill&) const = 0;
    virtual std::string name() const = 0;
};
class SelfPay : public Payer {
public: double amountCovered(const Bill&) const override { return 0.0; }
    std::string name() const override { return "SelfPay"; }
};
class Insurance : public Payer {
    double coverLimit, copayPercent;
public:
    Insurance(double limit, double copay) : coverLimit(limit), copayPercent(copay) {
        if (limit < 0 || copay < 0 || copay > 100) throw std::invalid_argument("invalid insurance settings");
    }
    double amountCovered(const Bill& b) const override { return std::min(coverLimit, b.total() * (1.0 - copayPercent / 100.0)); }
    std::string name() const override { return "Insurance"; }
};
class GovernmentScheme : public Payer {
    double packageRate;
public:
    explicit GovernmentScheme(double rate) : packageRate(rate) { if (rate < 0) throw std::invalid_argument("negative package"); }
    double amountCovered(const Bill& b) const override { return std::min(b.total(), packageRate); }
    std::string name() const override { return "GovernmentScheme"; }
};
class CorporatePayer : public Payer { // B4 extension added without editing existing payer classes
    double discountPercent;
public:
    explicit CorporatePayer(double d) : discountPercent(d) { if (d < 0 || d > 100) throw std::invalid_argument("invalid discount"); }
    double amountCovered(const Bill& b) const override { return b.total() * discountPercent / 100.0; }
    std::string name() const override { return "CorporatePayer"; }
};
int main() {
    std::vector<std::unique_ptr<Bill>> bills;
    bills.emplace_back(std::make_unique<OutPatient>("Ravi", 500, 1200));
    bills.emplace_back(std::make_unique<InPatient>("Meena", 3, 2500, 40000));
    bills.emplace_back(std::make_unique<DayCare>("Kumar", 18500));
    bills.emplace_back(std::make_unique<Emergency>("Sara", 3000, 2, 750));
    double sum = 0;
    for (const auto& b : bills) { b->print(); sum += b->total(); }
    std::cout << "Total " << sum << '\n';
    SelfPay self; Insurance insurer(60000, 20); GovernmentScheme govt(15000); CorporatePayer corp(30);
    const Payer* payers[] = {&self, &insurer, &govt, &corp};
    const Bill& example = *bills.at(1);
    for (const Payer* p : payers) std::cout << p->name() << " covers " << p->amountCovered(example) << '\n';
}
