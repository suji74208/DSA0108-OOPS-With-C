# DSA01 – Assignment 5 (CO5)

**Topic:** Reliable Software with Runtime Polymorphism and Exceptions (Hospital Billing case study)

> Update this README with your own name, register number, GitHub repository link, and machine/compiler details before submission. This package is a worked reference; your assignment requires individual execution, screenshots and progressive commits.

## Repository layout
- `Task01/billing_demo.cpp` – abstract Bill hierarchy, four bill types, abstract payer hierarchy and extension examples
- `Task02/exception_tests.cpp` – validation, custom claim exception, catch/log/rethrow, RAII and failure demonstrations
- `Task03/benchmark.cpp` – virtual vs switch/tag vs `std::variant`/`std::visit benchmark at 1K, 1M, 10M
- `Task04/README.md` – production decision and extension exercise notes
- `Tests/` – output prediction programs and locally captured sample output
- `Report/Assignment5_Answers.md` – Part A design, pseudocode, diagrams, Part B interpretations and complexity
- `Report/Test_Evidence.md` – compilation/test log template


## Build and run
Requires a C++17 compiler (sample environment: g++ 14.2.0). Compile each task:

```bash
g++ -std=c++17 -Wall -Wextra Task01/billing_demo.cpp -o billing_demo
./billing_demo

g++ -std=c++17 -Wall -Wextra Task02/exception_tests.cpp -o exception_tests
./exception_tests

g++ -std=c++17 -O2 -Wall -Wextra Task03/benchmark.cpp -o benchmark
./benchmark
```

Address sanitizer runs:
```bash
g++ -std=c++17 -g -O1 -fsanitize=address -fno-omit-frame-pointer Task01/billing_demo.cpp -o billing_demo_asan
./billing_demo_asan

g++ -std=c++17 -g -O1 -fsanitize=address -fno-omit-frame-pointer Task02/exception_tests.cpp -o exception_tests_asan
./exception_tests_asan
```

Run output prediction programs (write predictions in your report first, then compare):
```bash
for f in Tests/predict_*.cpp; do g++ -std=c++17 -Wall -Wextra "$f" -o /tmp/pred && /tmp/pred; done
```

## Progressive commits (one per task minimum)
Example sequence (make commits after completing and testing each task):
```bash
git init
git add Report/Assignment5_Answers.md && git commit -m "Add Part A design and pseudocode"
git add Tests/predict_virtual_destructor.cpp && git commit -m "Add virtual destructor prediction test"
git add Task01 && git commit -m "Implement polymorphic hospital billing"
git add Task02 && git commit -m "Add exception and recovery experiments"
git add Task03 && git commit -m "Add dispatch and performance benchmark"
git add Task04 Report Tests README.md && git commit -m "Complete engineering decision and test evidence"
```
Create the GitHub repository named `DSA01-<RegisterNumber>-Assignment5`, add its remote, and push commits. Include your real GitHub URL in your report and cover page.

## Important evidence to collect yourself
- Terminal screenshots of each program and sanitizer run
- Compiler version and exact commands used
- Prediction written before execution, then actual output and explanation
- Benchmark timings from your own machine; use repeated runs and report average/median
- Fill in `Report/Test_Evidence.md` with your own details
