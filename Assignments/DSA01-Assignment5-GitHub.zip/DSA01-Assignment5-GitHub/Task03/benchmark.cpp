#include <memory>
#include <chrono>
#include <iostream>
#include <vector>
#include <variant>
#include <cstdint>
struct BillBase { virtual ~BillBase()=default; virtual double total() const=0; };
struct OP : BillBase { double a,b; OP(double x,double y):a(x),b(y){} double total()const override{return a+b;} };
struct IP : BillBase { double rate; int days; double extra; IP(double r,int d,double e):rate(r),days(d),extra(e){} double total()const override{return rate*days+extra;} };
struct Tagged { int kind; double a,b; int days; double extra; double total()const { switch(kind){case 0:return a+b; default:return a*days+extra;} } };
using VBill=std::variant<OP,IP>;
volatile double sink=0;
template<class F> double time_ms(F f){auto s=std::chrono::steady_clock::now(); f(); return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-s).count();}
int main(){for(size_t n:{1000u,1000000u,10000000u}){
 std::vector<std::unique_ptr<BillBase>> poly; std::vector<Tagged> tagged; std::vector<VBill> variants; poly.reserve(n);tagged.reserve(n);variants.reserve(n);
 for(size_t i=0;i<n;i++){if(i%2){poly.emplace_back(new IP(2500,3,40000));tagged.push_back({1,2500,0,3,40000});variants.emplace_back(IP(2500,3,40000));}else{poly.emplace_back(new OP(500,1200));tagged.push_back({0,500,1200,0,0});variants.emplace_back(OP(500,1200));}}
 double t1=time_ms([&]{double x=0;for(auto&b:poly)x+=b->total();sink=x;});
 double t2=time_ms([&]{double x=0;for(auto&b:tagged)x+=b.total();sink=x;});
 double t3=time_ms([&]{double x=0;for(auto&b:variants)x+=std::visit([](auto&v){return v.total();},b);sink=x;});
 std::cout<<n<<" bills: virtual="<<t1<<"ms switch="<<t2<<"ms variant="<<t3<<"ms totals="<<sink<<'\n';
 }}
