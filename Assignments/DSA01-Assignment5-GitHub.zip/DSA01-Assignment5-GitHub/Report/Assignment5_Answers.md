# Assignment 5 – CO5: Reliable Software with Runtime Polymorphism and Exceptions

> Personalize the cover page/README with your name and register number. Predictions are written before the included runs; timings and screenshots must be recorded on your own machine for submission.

## Part A – Design

### A1.1 Common Bill interface
Common data: patient identifier/name, bill reference (recommended extension), date (recommended extension). Common operations: `total() const`, `type() const`, and `print() const`. `total()` and `type()` must dispatch to the concrete bill type; `print()` can be implemented once in the base class and call virtual operations.

### A1.2 Hierarchy and UML

```mermaid
classDiagram
  class Bill {
    # patient : string
    +Bill(patient)
    +total() double* 
    +type() string
    +print() void
    +~Bill() virtual
  }
  Bill <|-- OutPatient
  Bill <|-- InPatient
  Bill <|-- DayCare
  Bill <|-- Emergency
  class OutPatient { -consultation : double; -tests : double; +total() double; +type() string }
  class InPatient { -days : int; -perDay : double; -surgery : double; +total() double; +type() string }
  class DayCare { -packagePrice : double; +total() double; +type() string }
  class Emergency { -base : double; -hours : int; -perHour : double; +total() double; +type() string }
```
`total()` is pure virtual (`= 0`); `type()` is virtual and can have a base default; derived `total()` and `type()` are overrides. The destructor is virtual.

### A1.3 Pseudocode to process heterogeneous bills

**Algorithm: TotalDailyBills**  
**Input:** `billPtr[0..n-1]`, each pointer references a valid Bill-derived object  
**Output:** total of all bills  
**Begin**
1. `dayTotal ← 0`
2. For `i ← 0` to `n-1` do
   - `dayTotal ← dayTotal + billPtr[i].total()`
3. Display `dayTotal`
4. **Return** `dayTotal`
**End**

**Alternative (tag + switch):** store a `BillRecord` with a type tag and fields, then switch on tag in `total()`. Both process n records in O(n) total time, O(1) per bill. A tagged record may reserve space for all fields and can become cumbersome as types grow; a new kind requires modifying the tag, switch and record logic. Polymorphic objects use O(1) per bill, O(n) traversal and per-object storage for data plus implementation-specific overhead (commonly a vptr). A new derived type can be added without modifying the consumer loop.

### A2.1 Early vs late binding
Early binding resolves a call using the static type at compile time. Late binding uses the object's dynamic type at run time. With `Bill* b = new OutPatient(...)`, `b->total()` resolves to `OutPatient::total()` because `total()` is virtual. A non-virtual member call is selected using the static type.

### A2.2 Vtable sketch

```text
Bill vtable:        [ destructor, pure-virtual total, type -> "Bill" ]
OutPatient vtable:   [ destructor, OutPatient::total, OutPatient::type -> "OP" ]
InPatient vtable:    [ destructor, InPatient::total, InPatient::type -> "IP" ]

Bill* b points to an OutPatient object
  b->total() -> dispatch through object's vtable -> OutPatient::total()
```
The exact vtable layout is compiler/ABI implementation detail; this is conceptual. A non-virtual `show()` can call virtual `total()` because virtual dispatch is determined by the virtual member call, not by whether the caller (`show`) itself is virtual.

### A2.3 Virtual destructor
Deleting a derived object through a `Bill*` requires a virtual base destructor so the derived destructor and base destructor run in the correct order. Without it, delete-through-base is undefined behavior; sanitizer outcomes can vary and absence of a diagnostic is not proof of safety.

**Prediction (provided virtual destructor program):** `500 ~OPBill ~Bill ` then newline. The base `show()` prints 500 via virtual dispatch; delete invokes derived then base destructors. Removing virtual from the base destructor makes deleting through `Bill*` undefined behavior. Expected common observation may show only `~Bill`, but this must not be presented as guaranteed.

**Alternative using casts:** for k bill types, test type/cast branches and then call concrete methods; in the worst case O(k) checks per bill, O(nk) for n bills. Virtual dispatch is O(1) per bill, O(n) total. Vtable pointer overhead is implementation-dependent, commonly one pointer per polymorphic object.

### A3. Payer abstraction

```cpp
class Payer { public: virtual ~Payer()=default;
  virtual double amountCovered(const Bill&) const=0; };
class SelfPay : public Payer { /* coverage is 0 */ };
class Insurance : public Payer { double coverLimit, copayPercent; /* capped coverage */ };
class GovernmentScheme : public Payer { /* fixed package rates */ };
```
A corporate payer can be added as a new `Payer` subclass overriding `amountCovered`; existing payer and bill classes remain unchanged. Function pointers or `std::function<double(const Bill&)>` can hold coverage policy at runtime; both offer O(1) policy-call complexity. A function object can capture a cover limit, while an abstract class naturally stores policy state in members and provides a cohesive interface. Per-policy storage is the captured/member data plus callable/object overhead.

### A4. Exception strategy

Possible failures: negative bill/cover amounts; bill exceeding cover; unknown government package code; missing patient record; malformed numeric input (`std::invalid_argument` from conversion); numeric out-of-range (`std::out_of_range`); allocation failure (`std::bad_alloc`); file/database I/O failure; invalid payer configuration. Suggested hierarchy:

```text
std::exception
└── std::runtime_error
    └── BillingError
        ├── ClaimError
        ├── PatientRecordError
        └── PackageError
```
Use `std::invalid_argument` for bad caller inputs, `ClaimError` for policy rejection, `std::bad_alloc` for allocation failures and I/O-specific exceptions for persistence. Functions that validate or calculate may throw; only functions with a genuinely non-throwing contract should be marked `noexcept` (e.g., simple getters). Destructors must not throw; a throwing destructor during stack unwinding can terminate the program.

**Return-code alternative:** return `Status`/`expected`-style result with value and error code/message. Normal path remains O(1); error path also O(1), but callers must check every return and propagate status explicitly. Result storage needs a status and possibly message storage; control flow and error propagation code are more explicit.

### A5. Recovery and rethrowing

Catch low-level exceptions near the layer that can add context/logging; use `throw;` to rethrow the same active exception. Catch and report at the application boundary. RAII (`std::vector`, `std::string`, `std::unique_ptr`, file handles) releases resources automatically as stack unwinding destroys local objects.

**Prediction (Guard program):** `~f ~main caught 42` followed by newline. The inner `Guard` is destroyed first, then the main-scope guard during unwinding, then the matching `catch(int)` executes. The `not printed` statement is skipped because control transfers to the handler.

**Manual delete alternative:** allocate resources and delete them in every catch/return path. The execution complexity is still O(1) per cleanup, but code size and maintenance burden grow with the number of exit paths; every newly added error path can omit a delete and leak. RAII centralizes cleanup.

## Part B – Implementation and experiments

### B1. Completed polymorphic implementation
`Task01/billing_demo.cpp` completes the base interface and adds four bill types. The included run should print:

```text
OP Ravi: 1700
IP Meena: 47500
DC Kumar: 18500
ER Sara: 4500
Total 72200
SelfPay covers 0
Insurance covers 38000
GovernmentScheme covers 15000
CorporatePayer covers 14250
```
The insurance result for Meena is 80% of 47,500 = 38,000, below the 60,000 cap. The government coverage is capped at 15,000. Corporate covers 30%.

Removing `virtual` from `total()` makes the base function non-virtual; however, because it is pure virtual, the program is ill-formed and the compiler reports that virtual dispatch/override requirements are not met or the base declaration remains abstract depending on exactly what was changed. If the pure virtual declaration is also replaced with a non-virtual base implementation, calls through `Bill*` select the base implementation, not the derived totals.

**Template alternative:** instantiate and process separate vectors of `OutPatient` and `InPatient` (and each other type) with templated functions. Each bill calculation is O(1), total processing O(n); no vtable dispatch, but types cannot be mixed into one ordinary typed container without a wrapper/variant, and separate containers complicate ordering and common operations.

### B2. Error testing and completed code
`Task02/exception_tests.cpp` includes validation, a custom `ClaimError`, catch/log/rethrow, top-level catch demonstrations and RAII. It simulates `std::bad_alloc` by throwing it directly to avoid an ASan allocator-abort when an oversized request is attempted; a real allocator-failure experiment can be separately attempted with caution. `approve()` throws `invalid_argument` for negative values and `ClaimError` for over-cover; `settle()` logs and uses bare `throw;` to preserve the exception.

**Prediction for provided validate/process program:**
```text
ok done caught negative [log too large] caught too large 
```
100 passes and prints `ok done`; -5 throws `invalid_argument`, not caught by the inner `out_of_range` handler, then the outer handler prints `caught negative`; 2,000,000 throws `out_of_range`, is logged once inside `process`, rethrown and caught outside.

Completed `approve/settle` expected output:
```text
approved 40000
audit: exceeds cover
claim rejected: exceeds cover
error: negative amount
```
Replacing `throw;` with `throw e;` throws a new copy of the caught exception expression and can slice when caught through a base reference; bare `throw;` rethrows the original exception object and preserves its dynamic type.

**Optional alternative:** `std::optional<double>` can encode success/failure but cannot by itself carry a rich error; use a result type with an error code/message. For 1,000,000 records, expected runtime trends depend on compiler, CPU, and workload: success paths with return codes avoid exception machinery; exception-based validation is often comparable on success but invalid paths can be much slower because throwing/catching is costly. Do not fabricate measurements—fill the table using your runs.

| Invalid rate | Return/status measured (ms) | Exceptions measured (ms) |
|---|---:|---:|
| 0% | ______ | ______ |
| 1% | ______ | ______ |
| 50% | ______ | ______ |

### B3. Benchmark study
`Task03/benchmark.cpp` measures virtual dispatch, a tag/switch representation and `std::variant`/`std::visit for 1,000; 1,000,000; and 10,000,000 bills with `-O2`. It reports elapsed milliseconds and a checksum to discourage dead-code elimination. Run more than once and report median or average; compare only runs on the same machine/build. A 10-bill correctness check should be added or separately calculated before performance conclusions.

| N bills | Virtual (ms) | Switch (ms) | variant/visit (ms) |
|---:|---:|---:|---:|
| 1,000 | ____ | ____ | ____ |
| 1,000,000 | ____ | ____ | ____ |
| 10,000,000 | ____ | ____ | ____ |

All approaches are O(n) total time. `variant` stores the largest alternative plus a discriminator (and alignment padding); virtual objects typically include per-object vptr and may be separately allocated. Switch/tag data may have compact predictable storage. Actual timings vary with optimization, memory locality, allocator overhead and CPU.

**Exception-vs-status experiment:** create a separate loop that validates the same million amounts for 0%, 1%, and 50% invalid rates, uses a checksum/count, and times status and exception variants separately. Keep test input identical and compile `-O2`. Interpret performance alongside readability and error propagation, not speed alone.

**Variant alternative:** use `std::variant<OutPatientBill, InPatientBill, DayCareBill, EmergencyBill>` and `std::visit` with an overloaded visitor. It gives closed-set type safety and often good locality; adding a type requires changing the variant declaration/visitor, unlike open-ended subclassing. Per element space is at least the largest alternative plus tag/alignment.

### B4. Production decision and extension
The included `DayCare`, `Emergency`, and `CorporatePayer` classes demonstrate adding bill/payer types without editing existing concrete classes. The example uses `std::unique_ptr` so objects are destroyed automatically. Run it under AddressSanitizer. A suitable decision for 15 hospitals and 200,000 bills/day: runtime polymorphism is a maintainable choice when new bill/payer types are added frequently and heterogeneous lists are valuable. Exception handling is appropriate for exceptional invalid inputs and infrastructure failures, but routine high-frequency validation failures may be better represented with explicit result/status values if measurements show exception overhead. Keep billing rules, validation, audit logging and persistence separated; verify calculations and sanitizer tests before production.

**Configuration/plugin alternative:** rules stored in validated configuration are interpreted/looked up at runtime. Rule evaluation can be O(1) for indexed lookup or O(r) if scanning r rules; space is O(r). It lowers compile/deploy effort for rate-only changes but adds schema validation, versioning, security and rule-correctness risk. C++ classes are safer for complex behavior but require code review, build and deployment.

## Complexity summary
| Technique | Per bill | n-bill batch | Space per item (conceptual) |
|---|---|---|---|
| Virtual interface | O(1) dispatch + calculation | O(n) | bill data + commonly vptr |
| Tag/switch | O(1) branch + calculation | O(n) | tag + fields (may reserve all fields) |
| dynamic_cast chain | up to O(k) type tests | O(nk) worst case | object + RTTI implementation overhead |
| Templates | O(1), compile-time dispatch | O(n) per typed container | concrete object; separate containers |
| std::variant/visit | O(1) alternative dispatch | O(n) | largest alternative + tag/alignment |
| Status/return code | O(1) check | O(n) | status plus optional error data |
| Exception | O(1) on normal path; expensive exceptional path | O(n) normal validation | exception object only when thrown, implementation-dependent |
| Configuration rule | O(1) indexed lookup or O(r) scan | O(n) or O(nr) | rules + lookup structures |
