# Test Evidence – Fill in using your own machine

## Environment
- Student name: ___________________
- Register number: ___________________
- OS/device: ___________________
- Compiler: `g++ --version` → ___________________
- GitHub URL: ___________________

## Compile/run evidence
Commands used: ___________________
Screenshot filenames: ___________________

## ASan evidence
Commands used: ___________________
Observed result: ___________________
Screenshot filename: ___________________

## Performance measurements (repeat runs; record median or mean)
| Dataset size | Virtual (ms) | Switch (ms) | variant/visit (ms) | Notes |
|---:|---:|---:|---:|---|
| 1,000 | | | | |
| 1,000,000 | | | | |
| 10,000,000 | | | | |


## Status vs exceptions (1,000,000 validations)
| Invalid % | Return/status (ms) | Exceptions (ms) | Notes |
|---:|---:|---:|---|
| 0 | | | |
| 1 | | | |
| 50 | | | |

Do not copy invented benchmark timings. Performance results vary with machine/compiler/flags and must be measured locally.
