# Task B4 – Extension and Production Decision

The completed reference implementation in `Task01/billing_demo.cpp` extends the design with `DayCare`, `Emergency`, and `CorporatePayer`. Existing concrete classes are not edited to add these new types; the processing loop consumes the common interfaces.


## Production recommendation
A polymorphic design is a reasonable fit for the hospital group because bill and payer types change often, heterogeneous bills are processed through a common interface, and the extension surface is open. Keep exceptions for exceptional validation/infrastructure failures. For routine invalid-claim outcomes at very high volume, compare a status/result design using the benchmark data collected on the deployment target. Use smart pointers/RAII, audit logging and sanitizer tests in CI.

## Configuration/plugin alternative
Rate-only policies may be configuration-driven, validated against a schema and versioned. An indexed lookup can be O(1), while scanning r rules is O(r); storing rules requires O(r) space. This can avoid a C++ build for rate changes, but it introduces rule parsing, validation, versioning, security and operational risk. Use plugins/configuration for simple policy data; keep complex behavior in reviewed code.
