#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

class Cart {
    std::string items_[10];
    double prices_[10]{};
    int count_ = 0;
    double discount_ = 0.0;

public:
    Cart& add(const std::string& item, double price) {
        if (count_ < 10 && price >= 0.0) {
            items_[count_] = item;
            prices_[count_] = price;
            ++count_;
        }
        return *this;
    }

    Cart& setDiscount(double discount) {
        this->discount_ = (discount >= 0.0 && discount <= 100.0)
                              ? discount : 0.0;
        return *this;
    }

    double total() const {
        double sum = 0.0;
        for (int i = 0; i < count_; ++i) sum += prices_[i];
        return sum * (100.0 - discount_) / 100.0;
    }
};

int main() {
    // (a) Direct object use
    Cart first;
    first.add("Rice", 60).add("Dal", 120).setDiscount(10);

    // (b) Pointer to an existing object
    Cart* pointer = &first;
    pointer->add("Oil", 180);

    // (c) Reference to an object
    Cart& reference = first;
    reference.setDiscount(10);

    // (d) Dynamically allocated object with matching delete
    Cart* dynamicCart = new Cart;
    dynamicCart->add("Milk", 50);
    std::cout << "Dynamic cart total: " << dynamicCart->total() << '\n';
    delete dynamicCart;

    std::cout << std::fixed << std::setprecision(2)
              << "First cart total: " << pointer->total() << '\n';

    Cart second;
    second.add("Vegetables", 250).add("Fruit", 150);
    Cart* activeCarts[] = {&first, &second};
    std::size_t best = 0;
    for (std::size_t i = 1; i < 2; ++i) {
        if (activeCarts[i]->total() > activeCarts[best]->total()) best = i;
    }
    std::cout << "Highest active cart total: "
              << activeCarts[best]->total() << '\n';
}
