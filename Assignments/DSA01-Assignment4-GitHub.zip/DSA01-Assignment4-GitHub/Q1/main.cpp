#include <iostream>
#include <memory>
#include <string>
#include <vector>

class Staff {
private:
    std::string name_;
    int id_;

public:
    Staff(std::string name, int id) : name_(std::move(name)), id_(id) {}
    virtual ~Staff() = default;

    const std::string& name() const { return name_; }
    int id() const { return id_; }
    virtual double pay() const = 0;
};

class Professor : public Staff {
private:
    double basic_;
    double research_;

public:
    Professor(std::string name, int id, double basic, double research)
        : Staff(std::move(name), id), basic_(basic), research_(research) {}
    double pay() const override { return basic_ * 1.42 + research_; }
};

class LabAssistant : public Staff {
private:
    double basic_;

public:
    LabAssistant(std::string name, int id, double basic)
        : Staff(std::move(name), id), basic_(basic) {}
    double pay() const override { return basic_ * 1.42; }
};

class GuestFaculty : public Staff {
private:
    double hours_;
    double rate_;

public:
    GuestFaculty(std::string name, int id, double hours, double rate)
        : Staff(std::move(name), id), hours_(hours), rate_(rate) {}
    double pay() const override { return hours_ * rate_; }
};

int main() {
    std::vector<std::unique_ptr<Staff>> payroll;
    payroll.push_back(std::make_unique<Professor>("Anu", 101, 50000, 8000));
    payroll.push_back(std::make_unique<LabAssistant>("Bala", 102, 30000));
    payroll.push_back(std::make_unique<GuestFaculty>("Chitra", 103, 40, 900));

    for (const auto& person : payroll) {
        std::cout << person->name() << " (" << person->id()
                  << ") pay = " << person->pay() << '\n';
    }
}
