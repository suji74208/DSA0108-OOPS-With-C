# Assignment 4 – Test Evidence Record

Fill this document after compiling and running each program. Insert genuine terminal screenshots in the corresponding task folder.

## Environment
- OS:
- `g++ --version` output:
- Compile flags:
- Date tested:

## Task evidence
| Task | Compile successful? | Runtime result | Screenshot filename | Notes |
|---|---|---|---|---|
| Q1 | [ ] | | | |
| Q2 | [ ] | | | |
| Q3 | [ ] | | | |
| Q4 | [ ] | | | |
| Q5 | [ ] | | | |
| Q6 | [ ] | | | |

## Prediction-before-execution worksheet
Write your prediction before running the example. Preserve the first prediction, then add the observed output and explain any difference.

### Task 2 virtual-base constructor trace
- My prediction (written before execution):
- Actual output:
- Explanation:

### Task 3 Vehicle/Engine/Car trace
- My prediction (written before execution):
- Actual output:
- Explanation:

### Task 4 static vs virtual call
- My prediction (written before execution):
- Actual output:
- Explanation:

## Experiments
- `sizeof(TeachingAssistant)` with virtual inheritance:
- `sizeof(TeachingAssistant)` without virtual inheritance:
- Compiler and flags:
- `-Wreorder` warning text after intentionally reordering initializer list:
- AddressSanitizer command:
- Actual AddressSanitizer output (attach screenshot or paste report):

## GitHub commit evidence
Record the commit hash for each task:
- Q1:
- Q2:
- Q3:
- Q4:
- Q5:
- Q6:
