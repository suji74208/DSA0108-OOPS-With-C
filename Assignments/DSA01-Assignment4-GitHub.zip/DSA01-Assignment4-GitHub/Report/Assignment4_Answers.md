# Assignment 4 – Written Answers (CO4)

**Name:** [Your Name]  
**Register number:** [Your Register Number]  
**GitHub link:** [Paste repository URL]

> The explanations and code are a worked starting point. Run the programs and replace all machine-specific evidence, measurements and prediction notes with your own observations.

## Task 1 – Class design review

### 1.1 Diagnosis
1. `name`, `id` and basic-pay information are duplicated in multiple classes.
2. Public data members allow invalid or inconsistent state to be assigned directly.
3. `name/id` and `nm/code` use inconsistent names for equivalent concepts.
4. `da` is stored but never used by either pay calculation.
5. The literal `0.42` is a magic number; a named constant or policy is clearer.
6. A new staff category requires more duplicated fields and repeated processing logic.
7. Separate unrelated concrete types make a single polymorphic payroll loop difficult.
8. `GuestFaculty` has a different pay basis, but can still share identity and a common interface.

### 1.2 Repaired hierarchy
`Q1/main.cpp` implements an abstract `Staff` base with private identity data and a pure virtual `pay()`. `Professor`, `LabAssistant` and `GuestFaculty` override it. The payroll owns objects using `std::unique_ptr<Staff>`.

UML (text form):
```text
                 <<abstract>>
                    Staff
             - name : string
             - id : int
             + pay() : double {abstract}
                 /   |   \
                /    |    \
       Professor LabAssistant GuestFaculty
       - basic   - basic      - hours
       - research             - rate
```

### 1.3 Design defence (under 100 words)
The base class stores the information shared by every staff member and defines one common `pay()` interface. Each derived class contains only the data and formula specific to its category. Payroll code can therefore process every employee through a `Staff` pointer without checking the concrete type. To add a category, create a new derived class and override `pay()`; the existing payroll loop does not need modification.

### Alternative: one class plus a type switch
A single `Staff` class would store all possible fields (basic, research, hours and rate), plus a category code. `pay()` would switch on that code. Both a switch and virtual dispatch take O(1) time per call for this fixed number of alternatives. The single class may waste space because each object reserves fields unused by its category. Adding a category changes the enum/type code, the switch, construction/validation logic and possibly reporting code. In the hierarchy, the new type is primarily a new derived class.

---

## Task 2 – From requirement to hierarchy

### 2.1 Relationships
- `Student is-a Person`: public inheritance; single inheritance.
- `Staff is-a Person`: public inheritance; single inheritance.
- `TeachingAssistant is-a Student` and `is-a Staff`: multiple inheritance; with the two branches from `Person`, this is a diamond and forms a hybrid hierarchy.
- `ResearchScholar is-a Student`: multilevel inheritance (`Person -> Student -> ResearchScholar`).
- `Address` or other contact/location details would be has-a member objects, not inheritance, if represented as separate value types.

### 2.2 Diamond resolution
Without virtual inheritance, a `TeachingAssistant` contains one `Person` subobject through `Student` and another through `Staff`. Accessing `name` is ambiguous and the identity data is duplicated. Declaring both intermediate classes as `virtual public Person` makes them share one virtual `Person` base subobject. The most-derived class (`TeachingAssistant`) is responsible for initializing that virtual base.

### 2.3 Class design
See `Q2/main.cpp`. The two branches use `virtual public Person`; `TeachingAssistant` publicly inherits from both because it should be usable as either a student or staff member. `ResearchScholar` publicly inherits from `Student`.

### 2.4 Access table
Assume `Person` has public, protected and private members:

| Member declared in Person | Student : public Person | Student : protected Person | Student : private Person |
|---|---|---|---|
| public | public | protected | private |
| protected | protected | protected | private |
| private | inaccessible directly | inaccessible directly | inaccessible directly |

Private base members still exist in the base subobject; derived code cannot access them directly. Public/protected base member functions may provide controlled access.

### Predict-the-output example
Prediction to write before running:
```text
Person Student Staff TA
```
`Person` is initialized before either direct base because it is a virtual base. It is initialized once by the most-derived `TeachingAssistant`. Then direct bases are constructed in their declaration order (`Student`, then `Staff`), followed by the `TeachingAssistant` body. Removing `virtual` creates two `Person` subobjects, so the expected constructor trace is:
```text
Person Student Person Staff TA
```
Compiler output for the modified program depends on the exact compiler and whether ambiguous members are accessed; record the actual diagnostic rather than inventing one.

### Alternative: composition
With `TeachingAssistant` containing a `Student` and a `Staff` member, it has-a student and has-a staff record rather than being both types. In the direct composition design, each member can itself contain a `Person`, so there may be two `Person` subobjects. Access is explicit (`ta.student.name()` or `ta.staff.name()`), avoiding ambiguity but duplicating identity. `sizeof` must be measured on the actual compiler because padding and implementation details affect it. Direct member access is O(1), as is access through a virtual-base design; the principal difference is object layout and semantics, not asymptotic time.

---

## Task 3 – Constructors and member classes

### 3.1 Initializer lists
The `Student` constructor in `Q3/main.cpp` initializes `Person`, `regNo_`, `home_` and `course_` in its initializer list. In a virtual-inheritance diamond, the most-derived class initializes the virtual base because it alone knows which virtual-base constructor arguments are appropriate for the complete object. An intermediate base's virtual-base initializer is ignored when that intermediate object is part of a more-derived object.

### 3.2 Member classes
`Address` and `Course` are value members. `Student` passes the city and PIN to `Address`, and the course title to `Course`, in its initializer list.

### 3.3 Construction/destruction trace
For `Car : Vehicle` with member `Engine e`, construction is:
```text
Vehicle Engine Car
```
Destruction is reverse order:
```text
~Car ~Engine ~Vehicle
```
The separator printed inside the scope appears between construction and destruction. General rule: virtual bases first; then direct bases in declaration order; then members in member declaration order; then the derived constructor body. Destruction reverses this order.

### 3.4 Experiment
Remove `virtual` from both `Student` and `Staff` inheritance in Task 2 and record the changed trace and `sizeof(TeachingAssistant)` on your compiler. Two `Person` subobjects replace the single shared virtual base. Exact size is ABI/compiler-dependent; do not copy a size from another machine.

### Complete-the-code constructor
The required constructor form is:
```cpp
Student(const std::string& n, int a, long long r,
        const std::string& city, int pin)
    : Person(n, a), regNo(r), home(city, pin) {}
```
C++ initializes members in their declaration order, not the order written in the initializer list. Reordering initializers to disagree with declaration order can trigger `-Wreorder` with `-Wall`.

### Alternative: dynamically allocated Address
A pointer member would store only an address in the `Student` object, but require a separate heap allocation. Construction must allocate `Address`; destruction must `delete` it. A correct copy constructor and copy-assignment operator must deep-copy the pointed-to object (or ownership should be represented with a suitable smart pointer). Allocation/deallocation add runtime overhead; the pointer adds `sizeof(Address*)` bytes plus allocator overhead for the separately allocated object. A value member is simpler and manages its lifetime automatically.

---

## Task 4 – Pointers to derived classes

### 4.1 Defects
1. `rate()` is non-virtual, so `Account*` calls `Account::rate()` even when it points to a `SeniorAccount`.
2. `Account` has a non-virtual destructor. Deleting a derived object through `Account*` is undefined behaviour.
3. `SeniorAccount` allocates `history` dynamically; if the derived destructor is not invoked, the allocation is not released.
4. `Account copy = SeniorAccount();` slices the derived object: only the `Account` base subobject is copied.

### 4.2 Evidence
Compile a deliberately defective reproduction with AddressSanitizer and destructor logging. Save the actual sanitizer report. Undefined behaviour does not guarantee the same diagnostic on every run/compiler. The repaired version in `Q4/main.cpp` has a virtual destructor and uses owning smart pointers.

### 4.3 Repair
Make the polymorphic operation virtual and mark overrides with `override`. Give a polymorphic base a virtual destructor. Store derived objects through `std::unique_ptr<Account>` (or use references when ownership is elsewhere) rather than copying them into a `vector<Account>`.

### 4.4 Prevention rules
- A base class intended for deletion through a base pointer must have a virtual destructor.
- Declare derived overrides with `override`, so signature mismatches are diagnosed.

### Predict-the-output
For the supplied program:
```text
3.5 4 3.5
```
`p->rate()` is statically bound because `rate()` is non-virtual, so it calls `Account::rate`. `p->vrate()` uses dynamic dispatch and calls `SeniorAccount::vrate`. `copy.vrate()` calls the base implementation because `copy` is a distinct `Account` object created by slicing.

### Alternative: vector of unique_ptr
`std::vector<std::unique_ptr<Account>>` keeps polymorphic objects and automatically destroys them. Processing n accounts remains O(n), and each virtual charge/rate call is O(1). The three original issues are addressed by virtual dispatch, virtual destruction and pointer-based ownership. Slicing can still happen if code explicitly copies a derived object into an `Account` value elsewhere; smart pointers do not prevent every possible slicing operation.

---

## Task 5 – Pointers to objects and `this`

### 5.1 Four access forms
`Q5/main.cpp` demonstrates:
- Direct object: `cart.add(...)`
- Pointer to existing object: `ptr->add(...)`
- Reference: `Cart& ref = cart; ref.total()`
- Dynamic object: `new Cart`, use `->`, then `delete`

`this` is an implicit pointer to the current object inside a non-static member function. `*this` is the current object as an lvalue. Returning `Cart&` allows chaining without copying.

### 5.2 Highest total
The example stores addresses in an array of `Cart*` and compares `activeCarts[i]->total()` using indexing. Finding the maximum among n carts takes O(n) time and O(1) additional working space.

### 5.3 Comparison

| Form | Lifetime/ownership | Typical use |
|---|---|---|
| Direct object | Automatic or enclosing scope | Preferred simple local object |
| Pointer to existing object | Does not own target | Optional/reseatable access; check validity |
| Reference | Does not own target; normally must bind at initialization | Required non-null alias |
| `new` pointer | Caller owns allocation until `delete` | Prefer smart pointers in modern C++ |

If `add()` returned `Cart` by value, each call would return a copy. Chaining would operate on temporaries after the first call; changes may not affect the original cart, and extra copying may occur. Returning `Cart&` preserves the same object.

### Alternative: vector<Cart>
The maximum search remains O(n). A vector of objects stores the objects themselves contiguously (subject to their internal representation), whereas an array of pointers stores one pointer per entry and points elsewhere. Vector growth may reallocate its storage and invalidate pointers/references/iterators to its elements. A vector of owning smart pointers avoids moving the separately allocated cart objects when the vector's pointer array reallocates.

---

## Task 6 – Vehicle rental design challenge

### Stage 1: Entities and requirements
- Every vehicle has registration and daily rental rate.
- Motor vehicles additionally have fuel/charge level and service due date.
- Cars have seating capacity.
- Electric cars have battery capacity and energy price per kWh.
- Fleet supports rent, return, list and category-specific charge calculations.
- New vehicle types must be addable without modifying existing concrete classes or the fleet-processing loop.

### Stage 2: Hierarchy
```text
                    <<abstract>>
                       Vehicle
            - registration : string
            - dailyRate : double
            - rented : bool
            + rent(), giveBack()
            + charge(days, lateFee) : double {abstract}
            + describe() : void {abstract}
                         |
       +-----------------+-------------------+
       |                 |                   |
    Bicycle         MotorVehicle          (future types)
                     /       \
               TwoWheeler    +------------------+
                             |                  |
                            Car             ElectricCar

ElectricBus is added as another MotorVehicle-derived type.
```
`Vehicle` is abstract because every concrete type supplies `charge()` and `describe()`. The fleet uses base-class owning pointers.

### Stage 3: Critical decisions
- Common registration, daily rate and rental state belong in `Vehicle`.
- Motor-specific service and fuel/charge data belong in `MotorVehicle`.
- Category-only data belongs in the relevant derived class.
- `charge()` and `describe()` are pure virtual; the destructor is virtual.
- `rent()` and `giveBack()` are common non-virtual operations.
- `std::vector<std::unique_ptr<Vehicle>>` safely owns heterogeneous objects.

### Stage 4: Class and pseudocode
The complete declarations and implementation are in `Q6/main.cpp`.

SIMATS-style algorithmic pseudocode:
```text
ALGORITHM RentVehicle(vehicle)
    IF vehicle is already rented THEN
        RETURN failure
    END IF
    mark vehicle as rented
    RETURN success
END ALGORITHM

ALGORITHM ReturnVehicle(vehicle, daysUsed, lateFee)
    IF vehicle is not rented THEN
        RETURN failure
    END IF
    amount <- vehicle.charge(daysUsed, lateFee)
    mark vehicle as returned
    RETURN amount
END ALGORITHM

ALGORITHM ListFleet(fleet)
    FOR EACH vehicle IN fleet
        vehicle.describe()
    END FOR
END ALGORITHM
```

### Stage 5: Demonstration and extension
The program creates a bicycle, two-wheeler, car, electric car and an added electric bus. It lists each, rents it, calculates a two-day charge plus a late fee, and returns it. `ElectricBus` is added as a new derived class; the vector and loop are unchanged.

### Alternative: one Vehicle plus type switch
Both a switch-based `charge()` and virtual dispatch are O(1) per call for a fixed set of categories; processing n vehicles is O(n). A single class reserves all category-specific fields, including fields unused by many objects. A polymorphic implementation may carry a vptr per object (implementation-dependent), while derived objects carry only their own fields plus base state. Adding a type to the switch design changes the type code, switch, validation and often creation/listing logic. The hierarchy adds a new derived class and leaves the processing loop intact.
