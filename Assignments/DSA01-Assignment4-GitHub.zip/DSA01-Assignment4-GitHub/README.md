# DSA01 – Assignment 4 (CO4): Designing Reusable Class Hierarchies

> Starter submission structure. Replace all personal details and generate your own execution evidence before submission.

## Student details
- Name: **[Your Name]**
- Register number: **[Your Register Number]**
- GitHub repository: `DSA01-[RegisterNumber]-Assignment4`
- Compiler: **g++ [record installed version]**

## Build standard
All programs are intended for C++17 and should be compiled with warnings enabled:

```bash
g++ --version
g++ -std=c++17 -Wall -Wextra -pedantic Q1/main.cpp -o q1
./q1
```

For Task 4 sanitizer evidence (where supported):
```bash
g++ -std=c++17 -Wall -Wextra -g -fsanitize=address -fno-omit-frame-pointer Q4/main.cpp -o q4_asan
./q4_asan
```

## Folder guide
- `Q1/` – Payroll hierarchy design and implementation
- `Q2/` – Person/Student/Staff/TeachingAssistant diamond and virtual inheritance
- `Q3/` – Derived constructors, member classes, construction/destruction order
- `Q4/` – Virtual dispatch, virtual destructor, object slicing, smart pointers
- `Q5/` – Object pointers, references, `this`, chaining and pointer collections
- `Q6/` – Extensible vehicle rental hierarchy and fleet demonstration
- `Report/Assignment4_Answers.md` – Written answers, UML sketches, access table, pseudocode and complexity comparisons
- `Report/Test_Evidence.md` – Evidence checklist and prediction worksheet

## Run each task
```bash
g++ -std=c++17 -Wall -Wextra -pedantic Q1/main.cpp -o q1 && ./q1
g++ -std=c++17 -Wall -Wextra -pedantic Q2/main.cpp -o q2 && ./q2
g++ -std=c++17 -Wall -Wextra -pedantic Q3/main.cpp -o q3 && ./q3
g++ -std=c++17 -Wall -Wextra -pedantic Q4/main.cpp -o q4 && ./q4
g++ -std=c++17 -Wall -Wextra -pedantic Q5/main.cpp -o q5 && ./q5
g++ -std=c++17 -Wall -Wextra -pedantic Q6/main.cpp -o q6 && ./q6
```

## Progressive commits
Make at least one meaningful commit per task, for example:
```bash
git add Q1 Report/Assignment4_Answers.md
git commit -m "Complete Task 1 payroll hierarchy"
```
Repeat for Q2 through Q6. Do not upload everything as one final commit.

## Before submission
1. Replace personal details and repository link.
2. Compile and run every program yourself using the exact commands above.
3. Complete the prediction worksheets **before** running the corresponding examples; record any corrections honestly.
4. Add terminal screenshots and genuine AddressSanitizer output where available.
5. Record your actual compiler version, `sizeof` measurements and any warnings on your machine.
6. Verify that your GitHub repository is accessible to faculty.
