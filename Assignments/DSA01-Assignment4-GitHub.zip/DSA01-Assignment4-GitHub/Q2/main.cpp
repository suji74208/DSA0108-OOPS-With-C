#include <iostream>
#include <string>

class Person {
protected:
    std::string name_;
    int id_;
    std::string phone_;

public:
    Person(std::string name, int id, std::string phone)
        : name_(std::move(name)), id_(id), phone_(std::move(phone)) {}
    virtual ~Person() = default;

    const std::string& name() const { return name_; }
};

class Student : virtual public Person {
protected:
    std::string programme_;
    double cgpa_;

public:
    Student(std::string name, int id, std::string phone,
            std::string programme, double cgpa)
        : Person(std::move(name), id, std::move(phone)),
          programme_(std::move(programme)), cgpa_(cgpa) {}
};

class Staff : virtual public Person {
protected:
    std::string department_;
    double salary_;

public:
    Staff(std::string name, int id, std::string phone,
          std::string department, double salary)
        : Person(std::move(name), id, std::move(phone)),
          department_(std::move(department)), salary_(salary) {}
};

class TeachingAssistant : public Student, public Staff {
public:
    TeachingAssistant(std::string name, int id, std::string phone,
                      std::string programme, double cgpa,
                      std::string department, double salary)
        : Person(name, id, phone),
          Student(name, id, phone, programme, cgpa),
          Staff(name, id, phone, department, salary) {}
};

class ResearchScholar : public Student {
private:
    double fellowship_;

public:
    ResearchScholar(std::string name, int id, std::string phone,
                    std::string programme, double cgpa, double fellowship)
        : Person(std::move(name), id, std::move(phone)),
          Student("", 0, "", std::move(programme), cgpa),
          fellowship_(fellowship) {}
};

int main() {
    TeachingAssistant ta("Kavya", 501, "9876543210",
                         "M.E. CSE", 8.7, "CSE", 25000);
    std::cout << "Teaching assistant: " << ta.name() << '\n';
    std::cout << "A single shared Person base is used.\n";
}
