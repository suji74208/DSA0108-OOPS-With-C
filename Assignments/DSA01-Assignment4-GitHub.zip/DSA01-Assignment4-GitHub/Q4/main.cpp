#include <iostream>
#include <memory>
#include <vector>

class Account {
public:
    virtual double rate() const { return 3.5; }
    virtual ~Account() { std::cout << "Account destructor\n"; }
};

class SeniorAccount : public Account {
    double* history_;

public:
    SeniorAccount() : history_(new double[100]{}) {}
    double rate() const override { return 4.0; }
    ~SeniorAccount() override {
        delete[] history_;
        std::cout << "SeniorAccount destructor\n";
    }
};

int main() {
    std::vector<std::unique_ptr<Account>> accounts;
    accounts.push_back(std::make_unique<Account>());
    accounts.push_back(std::make_unique<SeniorAccount>());

    for (const auto& account : accounts)
        std::cout << account->rate() << '\n';

    Account* base = new SeniorAccount();
    std::cout << "Base-pointer virtual rate: " << base->rate() << '\n';
    delete base;

    SeniorAccount senior;
    Account slicedCopy = senior; // Intentional slicing demonstration.
    std::cout << "Sliced copy rate: " << slicedCopy.rate() << '\n';
}
