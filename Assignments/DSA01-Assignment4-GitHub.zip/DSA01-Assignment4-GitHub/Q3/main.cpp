#include <iostream>
#include <string>

class Address {
    std::string city_;
    int pin_;

public:
    Address(std::string city, int pin) : city_(std::move(city)), pin_(pin) {
        std::cout << "Address constructed\n";
    }
    ~Address() { std::cout << "Address destroyed\n"; }
    std::string str() const { return city_ + "-" + std::to_string(pin_); }
};

class Person {
protected:
    std::string name_;
    int age_;

public:
    Person(const std::string& name, int age) : name_(name), age_(age) {
        std::cout << "Person constructed\n";
    }
    virtual ~Person() { std::cout << "Person destroyed\n"; }
};

class Course {
    std::string title_;

public:
    explicit Course(std::string title) : title_(std::move(title)) {
        std::cout << "Course constructed\n";
    }
    ~Course() { std::cout << "Course destroyed\n"; }
};

class Student : public Person {
    long long regNo_;
    Address home_;
    Course course_;

public:
    Student(const std::string& name, int age, long long regNo,
            const std::string& city, int pin, const std::string& course)
        : Person(name, age), regNo_(regNo), home_(city, pin), course_(course) {
        std::cout << "Student constructed\n";
    }
    ~Student() override { std::cout << "Student destroyed\n"; }

    void print() const {
        std::cout << regNo_ << ' ' << name_ << " (" << age_ << ") "
                  << home_.str() << '\n';
    }
};

class Engine {
public:
    Engine() { std::cout << "Engine "; }
    ~Engine() { std::cout << "~Engine "; }
};

class Vehicle {
public:
    Vehicle() { std::cout << "Vehicle "; }
    virtual ~Vehicle() { std::cout << "~Vehicle "; }
};

class Car : public Vehicle {
    Engine engine_;

public:
    Car() { std::cout << "Car "; }
    ~Car() override { std::cout << "~Car "; }
};

int main() {
    {
        Student student("Kavya", 19, 192311001, "Salem", 636001, "OOP");
        student.print();
    }
    std::cout << "-- order example --\n";
    {
        Car car;
        std::cout << "| ";
    }
    std::cout << '\n';
}
