#include <iomanip>
#include <iostream>
#include <memory>
#include <string>
#include <vector>

class Vehicle {
    std::string registration_;
    double dailyRate_;
    bool rented_ = false;

public:
    Vehicle(std::string registration, double dailyRate)
        : registration_(std::move(registration)), dailyRate_(dailyRate) {}
    virtual ~Vehicle() = default;

    const std::string& registration() const { return registration_; }
    double dailyRate() const { return dailyRate_; }
    bool isRented() const { return rented_; }

    bool rent() {
        if (rented_) return false;
        rented_ = true;
        return true;
    }
    bool giveBack() {
        if (!rented_) return false;
        rented_ = false;
        return true;
    }

    virtual double charge(int days, double lateFee = 0.0) const = 0;
    virtual void describe() const = 0;
};

class Bicycle : public Vehicle {
public:
    using Vehicle::Vehicle;
    double charge(int days, double lateFee = 0.0) const override {
        return dailyRate() * days + lateFee;
    }
    void describe() const override {
        std::cout << "Bicycle " << registration() << '\n';
    }
};

class MotorVehicle : public Vehicle {
    double fuelOrChargeLevel_;
    std::string serviceDue_;

public:
    MotorVehicle(std::string reg, double rate, double level, std::string due)
        : Vehicle(std::move(reg), rate), fuelOrChargeLevel_(level),
          serviceDue_(std::move(due)) {}
    double level() const { return fuelOrChargeLevel_; }
    const std::string& serviceDue() const { return serviceDue_; }
};

class TwoWheeler : public MotorVehicle {
public:
    using MotorVehicle::MotorVehicle;
    double charge(int days, double lateFee = 0.0) const override {
        return dailyRate() * days + lateFee;
    }
    void describe() const override {
        std::cout << "Two-wheeler " << registration()
                  << ", fuel/charge " << level()
                  << ", service " << serviceDue() << '\n';
    }
};

class Car : public MotorVehicle {
    int seats_;

public:
    Car(std::string reg, double rate, double level, std::string due, int seats)
        : MotorVehicle(std::move(reg), rate, level, std::move(due)), seats_(seats) {}
    double charge(int days, double lateFee = 0.0) const override {
        return dailyRate() * days + lateFee;
    }
    void describe() const override {
        std::cout << "Car " << registration() << ", seats " << seats_
                  << ", fuel " << level() << ", service " << serviceDue() << '\n';
    }
};

class ElectricCar : public MotorVehicle {
    double batteryKWh_;
    double pricePerKWh_;

public:
    ElectricCar(std::string reg, double rate, double level, std::string due,
                double batteryKWh, double pricePerKWh)
        : MotorVehicle(std::move(reg), rate, level, std::move(due)),
          batteryKWh_(batteryKWh), pricePerKWh_(pricePerKWh) {}
    double charge(int days, double lateFee = 0.0) const override {
        return dailyRate() * days + batteryKWh_ * pricePerKWh_ + lateFee;
    }
    void describe() const override {
        std::cout << "Electric car " << registration()
                  << ", battery " << batteryKWh_ << " kWh, charge level "
                  << level() << ", service " << serviceDue() << '\n';
    }
};

// Extension example: add a new derived type without editing Vehicle or the fleet loop.
class ElectricBus : public MotorVehicle {
    int seats_;

public:
    ElectricBus(std::string reg, double rate, double level, std::string due, int seats)
        : MotorVehicle(std::move(reg), rate, level, std::move(due)), seats_(seats) {}
    double charge(int days, double lateFee = 0.0) const override {
        return dailyRate() * days + seats_ * 2.0 + lateFee;
    }
    void describe() const override {
        std::cout << "Electric bus " << registration() << ", seats " << seats_ << '\n';
    }
};

int main() {
    std::vector<std::unique_ptr<Vehicle>> fleet;
    fleet.push_back(std::make_unique<Bicycle>("CYC-101", 100.0));
    fleet.push_back(std::make_unique<TwoWheeler>("BIK-202", 250.0, 70.0, "2027-02-01"));
    fleet.push_back(std::make_unique<Car>("CAR-303", 1200.0, 60.0, "2027-03-01", 5));
    fleet.push_back(std::make_unique<ElectricCar>(
        "EV-404", 1500.0, 85.0, "2027-04-01", 50.0, 8.0));
    fleet.push_back(std::make_unique<ElectricBus>(
        "BUS-505", 2200.0, 90.0, "2027-05-01", 30));

    for (const auto& vehicle : fleet) {
        vehicle->describe();
        if (vehicle->rent()) std::cout << "Rented successfully\n";
        else std::cout << "Already rented\n";

        const int rentalDays = 2;
        const double lateFee = 150.0;
        std::cout << "Rental charge: " << vehicle->charge(rentalDays, lateFee) << '\n';
        vehicle->giveBack();
        std::cout << "Returned\n";
    }
}
