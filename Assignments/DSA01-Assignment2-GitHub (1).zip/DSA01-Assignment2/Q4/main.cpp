#include <array>
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>

class SavingsAccount {
    std::string accountNumber;
    long long balancePaise;
    std::array<long long, 10> transactions{};
    int count = 0;
    int next = 0;
public:
    SavingsAccount(std::string number, long long opening)
        : accountNumber(std::move(number)), balancePaise(opening) {}
    void deposit(long long paise) {
        if (paise <= 0) return;
        balancePaise += paise;
        addTransaction(paise);
    }
    bool withdraw(long long paise) {
        if (paise <= 0 || paise > balancePaise) return false;
        balancePaise -= paise;
        addTransaction(-paise);
        return true;
    }
    void addTransaction(long long amount) {
        transactions[next] = amount;
        next = (next + 1) % static_cast<int>(transactions.size());
        if (count < static_cast<int>(transactions.size())) ++count;
    }
    void miniStatement() const;
};
void SavingsAccount::miniStatement() const {
    std::cout << "Account " << accountNumber << " | Balance Rs "
              << std::fixed << std::setprecision(2) << balancePaise / 100.0
              << "\nRecent transactions (oldest first):\n";
    int start = (count == 10) ? next : 0;
    for (int i = 0; i < count; ++i)
        std::cout << transactions[(start + i) % 10] << " paise\n";
}
int main() {
    SavingsAccount account("SB1001", 100000);
    account.deposit(5000);
    account.withdraw(1200);
    for (int i = 1; i <= 10; ++i) account.deposit(i * 100);
    account.miniStatement();
}
