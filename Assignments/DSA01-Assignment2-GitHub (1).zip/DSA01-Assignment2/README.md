# DSA01 – Assignment 2 (CO2): Functions and OOP in C++

Student name: [Enter your name]  
Register number: [Enter your register number]  
Compiler: g++ [enter version]  
Standard: C++17

## Compile and run
From the repository root:
```bash
g++ -std=c++17 -Wall -Wextra Q1/main.cpp -o q1
./q1
```
Replace Q1/q1 for each question. On Windows, run `q1.exe`.

## Contents
- Q1: Call by value, reference and pointer; reference return; default arguments.
- Q2: Return by reference, index alternative and safe reference example.
- Q3: Default arguments and overload resolution.
- Q4: Class with fixed-size circular transaction history.
- Q5: Static members and array of ticket objects.
- Q6: Friend and inline functions, correctness tests and timing loop.
- Q7: Diagnose shifting-history cost and compare with circular buffer.
- Report: written answers, predictions, complexity analysis and test evidence checklist.

## Submission checklist
- [ ] Replace student details.
- [ ] Run every program with your compiler.
- [ ] Save genuine terminal screenshots in each Q folder.
- [ ] Record `g++ --version` and exact compile commands.
- [ ] Measure Q6 at `-O0` and `-O2` on your own machine.
- [ ] Commit each question progressively (at least one commit per question).
- [ ] Add your GitHub repository link to the report and cover page.

Important: timings, compiler warnings and screenshots must be generated on your own machine. Do not submit fabricated measurements or screenshots.
