# Test Evidence Record

Fill this file after executing the programs on your own computer.

| Question | Test / input | Expected or check | Actual result | Screenshot filename |
|---|---|---|---|---|
| Q1 | value/reference/pointer | value unchanged; reference and pointer modify caller | [Fill] | [Fill] |
| Q2 | highest mark array | returned reference changes array element | [Fill] | [Fill] |
| Q3 | six overload calls | selected overload matches prediction | [Fill] | [Fill] |
| Q4 | more than 10 transactions | only latest 10 displayed | [Fill] | [Fill] |
| Q5 | 4 tickets, capacity 3 | three seats and one waiting | [Fill] | [Fill] |
| Q6 | before/after noon and equal time | correct minutes and comparison | [Fill] | [Fill] |
| Q6 | 10 million calls, -O0 | record elapsed milliseconds | [Fill] | [Fill] |
| Q6 | 10 million calls, -O2 | record elapsed milliseconds | [Fill] | [Fill] |
| Q7 | 100,000 history insertions | same last 10 values retained | [Fill] | [Fill] |

Compiler version (`g++ --version`): [Fill]  
Exact compile command(s): [Fill]  
Machine / OS: [Fill]
