# Assignment 2 – Written Answers and Analysis

**Student:** [Name]  
**Register Number:** [Register number]  
**GitHub link:** [Paste repository URL]

> First write each prediction in your notebook/report before compiling. The outputs below are reference predictions; execute the programs and record your actual terminal evidence separately.

## Q1 – Call by Value, Reference and Pointer (6)

### Prediction for the supplied program
```text
1 12 13
1 100
16 13 6
```
Explanation: `a` is passed by value, so its caller value remains 1. `b` is a reference to the caller's `b`, so it becomes 12. `c` is passed as a pointer and `*c` changes the caller's `c` to 13. `bigger(a,c)` returns a reference to the larger lvalue; `c` is larger, so assignment sets `c` to 100. `show(1)` uses y=5,z=10; `show(1,2)` uses z=10; the final call supplies all arguments.

### Complete-code TODO
```cpp
fee -= fee * percent / 100;
```
Expected:
```text
after call by value   : 45000
after call by reference: 40500
```
Call-by-value modifies a local copy. Reference and pointer parameters refer to the original object. A `const T&` is suitable when a large object should be read without copying or modification.

### Three parameter styles
- Value: independent local copy; caller unchanged.
- Reference: alias to caller object; caller can be modified.
- Pointer: stores an address; dereference to modify; can be null and should be checked.

### Design decision
For a sequence of concessions, calculate and return a new fee if the operation should be pure and easy to test. Use a reference when updating the existing student record is the clear required side effect. A practical design can calculate the final fee first, then assign it once.

### Alternative and complexity
All three are O(1) time for a fixed number of arithmetic operations. A `long long` value copy uses O(1) space. A large `Student` passed by value copies all its fields and any owned data (cost proportional to object size); reference/const-reference parameters pass an alias and avoid that object copy. Returning the new `long long` is also O(1).

## Q2 – Return by Reference and Its Dangers (4)

`highest()` scans the array and returns a reference to the maximum element. Thus `highest(marks,n) += 2` modifies the original array element. Returning a local automatic variable by reference is invalid: the variable's lifetime ends when the function returns, leaving a dangling reference; dereferencing it is undefined behaviour. Compilers commonly warn that a reference to a local variable is returned.

A non-const reference allows modification. A const reference allows reading but not modification through that reference. Returning a copy gives an independent value and cannot update the original array.

If using an index: `int i = highestIndex(marks,n); marks[i] += 2;`. If using a pointer: return `&marks[index]`, then check it is non-null before `*p += 2`. Finding the maximum is O(n) time and O(1) extra space for reference, index or pointer. For a vector, growth can reallocate storage and invalidate references and pointers to its elements; an index can remain usable after growth if the logical element ordering is preserved, but must be bounds-checked.

## Q3 – Default Arguments and Function Overloading (6)

The original declarations overlap: calls with one argument can match both `charge(double)` and the three-parameter function whose other parameters have defaults. The compiler cannot select a unique best overload, so the call is ambiguous.

The redesigned program uses:
- `charge(double, bool=false, bool=false)` for kg and optional services.
- `charge(int)` for grams.
- `charge(float)` to handle a float literal explicitly.
- `charge(const Parcel&)` for a parcel object.

### Six call predictions
| Call | Selected function | Reason |
|---|---|---|
| `charge(2)` | `charge(int)` | exact int match |
| `charge(2.0)` | double overload | exact double match |
| `charge(2.0f)` | float overload | exact float match |
| `charge(2.0,true)` | double overload | remaining parameter defaults |
| `charge(2.0,true,true)` | double overload | all arguments supplied |
| `charge(p)` | Parcel overload | exact Parcel reference match |

Overload resolution prefers exact match over promotion and promotion over standard conversion. Default arguments fill omitted trailing parameters; therefore they must be specified from the right. Overload resolution happens at compile time and has no run-time dispatch cost. A `Parcel` structure is easier to extend with many options, while overloads are convenient for distinct input types. Passing a large Parcel by const reference avoids copying.

## Q4 – Class with an Array Inside It (6)

`SavingsAccount` keeps account number, balance, ten transactions and count private. Public methods validate deposits/withdrawals and provide a mini-statement. Some methods are defined inside the class; `miniStatement()` is defined outside using `SavingsAccount::`.

Private data protects invariants: callers cannot directly set an invalid balance or corrupt transaction count. With shifting, adding the 11th transaction moves up to 9 entries: O(k) time. A circular index overwrites the oldest slot in O(1) time and needs a start/next index. Both use O(10) storage. For 50 transactions, only the array capacity and wrap-around bound need to change in a fixed-array design; a named constant makes this simpler.

A `deque` supports `push_back` and `pop_front` at the ends efficiently, while a circular buffer gives predictable fixed storage and O(1) insertion. The supplied program uses a circular array.

## Q5 – Static Members and Arrays of Objects (7)

The `issued` counter and `CAPACITY` belong to the class, so they are static. A static data member is declared in the class and defined once outside it (`int BusTicket::issued = 0;`). A static member function has no `this` pointer, so it cannot access an individual ticket's non-static `seat` or `name`.

An array of four objects invokes four constructors. Only the first three get seats; the fourth waits. A function-local array increments the same class counter each time it is constructed; the static count does not reset when the function returns. For separate buses, a `TicketOffice` instance is preferable because each bus needs its own capacity and count.

### Token prediction
```text
101 103 104 4
```
The static counter starts at 100. Three array elements and one extra object are constructed, so the constructor runs four times.

### BusTicket expected output
```text
Asha: Seat 1
Bala: Seat 2
Chitra: Seat 3
Dev: Waiting
Issued: 3
```
Global variable, static class member and a TicketOffice object's counter are all O(1) time and O(1) counter space. A class static member encapsulates one shared count for that class; a separate office object supports multiple independent buses more naturally.

## Q6 – Friend and Inline Functions (8)

Expected first line:
```text
205 false
```
09:45 is 585 minutes after midnight; 13:10 is 790 minutes. Difference is 205. Arrival is not earlier than departure, so `false`.

Expected second line:
```text
10 true false
```
11:55 to 12:05 is 10 minutes. 11:55 is earlier than 12:05. Equal times are not earlier.

A friend function is not a class member, but the class grants it access to private fields. It is called like a normal function (`minutesBetween(a,b)`), whereas a member is called through an object (`a.minutesTo(b)`). Friend functions suit symmetric comparisons of two objects. Inline is a request/permission for inline substitution; the compiler may ignore it. It also permits suitable definitions in headers. Making fields public weakens encapsulation and allows invalid states.

Alternative member functions or public getters can preserve encapsulation. Both designs are O(1) per comparison; after optimisation, timing may be similar. Compile and measure:
```bash
g++ -std=c++17 -O0 Q6/main.cpp -o q6_O0
./q6_O0
g++ -std=c++17 -O2 Q6/main.cpp -o q6_O2
./q6_O2
```
Record actual measured milliseconds on your computer. Do not invent timing values. For a deployment design, prefer member functions/getters unless symmetric operations genuinely need private access; use friend selectively.

## Q7 – Diagnose, Redesign and Validate (13)

### A. Diagnose
The original `ShiftHistory` removes the first vector element when full. Erasing the first element shifts the remaining entries, so each insertion after capacity is reached costs O(k).

### B. Objective
Keep only the latest 10 values and reduce each insertion to O(1), while preserving oldest-to-newest retrieval.

### C. Revised design
Use a circular buffer with a fixed-size vector, a `next` index and a `count`. Each new value overwrites the oldest slot and advances `next`. Extra metadata is O(1); storage remains O(k).

Pseudocode:
```text
add(value):
    buffer[next] = value
    next = (next + 1) modulo capacity
    count = min(count + 1, capacity)
```

### D. Prediction
For capacity k, insertion changes from O(k) shifting to O(1) overwrite. Memory remains O(k). For very small k, measured time difference may be small.

### E. Validation
`Q7/main.cpp` sends the same 100,000 values through both implementations, reports elapsed milliseconds, checks retained count and prints oldest/newest values. Run it repeatedly on the same machine/compiler and record results. The expected retained values are 99,990 through 99,999.

### F. Evaluation
The circular design meets the constant-time insertion objective and preserves the most recent values. It adds index logic and requires careful ordering when reading. The shifting version may be simpler for tiny histories or when contiguous oldest-first storage is important. Measurements can vary with compiler, optimisation, hardware and timing noise; report your own results.

## Final evidence checklist
- Prediction written before execution for Q1 and Q5.
- Q1–Q7 source files compiled and executed.
- Q2 warning demonstration: create a separate intentionally unsafe local-reference test only for compiler-warning capture; do not execute/dereference it.
- Q6 timings at both `-O0` and `-O2`.
- Q7 original-versus-redesigned timings using the same test size.
- Terminal screenshots saved in each Q folder.
- One progressive Git commit per question.
