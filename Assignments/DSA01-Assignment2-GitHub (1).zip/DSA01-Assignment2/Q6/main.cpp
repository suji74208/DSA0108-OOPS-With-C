#include <chrono>
#include <cstdlib>
#include <iostream>

class Time {
    int h, m;
public:
    Time(int hh, int mm) : h(hh), m(mm) {}
    friend int minutesBetween(const Time& a, const Time& b);
    friend bool earlier(const Time& a, const Time& b);
};
inline int minutesBetween(const Time& a, const Time& b) {
    int first = a.h * 60 + a.m;
    int second = b.h * 60 + b.m;
    return std::abs(first - second);
}
inline bool earlier(const Time& a, const Time& b) {
    return a.h < b.h || (a.h == b.h && a.m < b.m);
}
int main() {
    Time departure(9, 45), arrival(13, 10);
    std::cout << minutesBetween(departure, arrival) << ' '
              << std::boolalpha << earlier(arrival, departure) << '\n';

    Time beforeNoon(11, 55), afterNoon(12, 5), same(12, 5);
    std::cout << minutesBetween(beforeNoon, afterNoon) << ' '
              << earlier(beforeNoon, afterNoon) << ' '
              << earlier(same, afterNoon) << '\n';

    volatile long long sink = 0;
    auto start = std::chrono::steady_clock::now();
    for (int i = 0; i < 10000000; ++i)
        sink += minutesBetween(departure, arrival);
    auto finish = std::chrono::steady_clock::now();
    std::chrono::duration<double, std::milli> elapsed = finish - start;
    std::cout << "10M inline calls ms: " << elapsed.count()
              << " (sink " << sink << ")\n";
}
