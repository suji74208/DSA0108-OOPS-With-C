#include <chrono>
#include <iostream>
#include <vector>

// Original design: when full, erase the oldest item and shift the rest.
class ShiftHistory {
    std::vector<int> values;
    std::size_t capacity;
public:
    explicit ShiftHistory(std::size_t n) : capacity(n) {}
    void add(int value) {
        if (values.size() == capacity) values.erase(values.begin());
        values.push_back(value);
    }
    const std::vector<int>& data() const { return values; }
};

// Redesigned fixed-capacity circular history: overwrite oldest slot.
class CircularHistory {
    std::vector<int> values;
    std::size_t next = 0, count = 0;
public:
    explicit CircularHistory(std::size_t n) : values(n) {}
    void add(int value) {
        values[next] = value;
        next = (next + 1) % values.size();
        if (count < values.size()) ++count;
    }
    std::size_t size() const { return count; }
    int oldestFirst(std::size_t i) const {
        std::size_t start = (count == values.size()) ? next : 0;
        return values[(start + i) % values.size()];
    }
};
int main() {
    constexpr int N = 100000;
    ShiftHistory original(10);
    CircularHistory redesigned(10);

    auto t1 = std::chrono::steady_clock::now();
    for (int i = 0; i < N; ++i) original.add(i);
    auto t2 = std::chrono::steady_clock::now();
    for (int i = 0; i < N; ++i) redesigned.add(i);
    auto t3 = std::chrono::steady_clock::now();

    std::chrono::duration<double, std::milli> oldMs = t2 - t1;
    std::chrono::duration<double, std::milli> newMs = t3 - t2;
    std::cout << "Original shifting (ms): " << oldMs.count() << '\n'
              << "Circular buffer (ms): " << newMs.count() << '\n'
              << "Retained entries: " << original.data().size()
              << " and " << redesigned.size() << '\n'
              << "Circular oldest/newest: " << redesigned.oldestFirst(0)
              << '/' << redesigned.oldestFirst(9) << '\n';
}
