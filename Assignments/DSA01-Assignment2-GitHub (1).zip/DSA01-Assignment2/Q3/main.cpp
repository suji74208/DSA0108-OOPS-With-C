#include <iostream>
struct Parcel { double kg; bool express; bool insured; };

double charge(double kg, bool express = false, bool insured = false) {
    double total = kg * 50.0;
    if (express) total += 30.0;
    if (insured) total += 20.0;
    return total;
}
double charge(int grams) { return charge(static_cast<double>(grams) / 1000.0); }
double charge(float kg) { return charge(static_cast<double>(kg)); }
double charge(const Parcel& p) { return charge(p.kg, p.express, p.insured); }

int main() {
    Parcel p{2.0, true, true};
    std::cout << "charge(2) [int grams]: " << charge(2) << '\n';
    std::cout << "charge(2.0) [double kg]: " << charge(2.0) << '\n';
    std::cout << "charge(2.0f) [float kg]: " << charge(2.0f) << '\n';
    std::cout << "charge(2.0, true): " << charge(2.0, true) << '\n';
    std::cout << "charge(2.0, true, true): " << charge(2.0, true, true) << '\n';
    std::cout << "charge(Parcel): " << charge(p) << '\n';
}
