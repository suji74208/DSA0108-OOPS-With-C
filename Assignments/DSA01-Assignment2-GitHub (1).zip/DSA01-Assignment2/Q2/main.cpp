#include <iostream>
int& highest(int marks[], int n) {
    int index = 0;
    for (int i = 1; i < n; ++i)
        if (marks[i] > marks[index]) index = i;
    return marks[index];
}
int highestIndex(const int marks[], int n) {
    int index = 0;
    for (int i = 1; i < n; ++i)
        if (marks[i] > marks[index]) index = i;
    return index;
}
// A local automatic variable must NOT be returned by reference.
// This static variable is safe to return, but is shared between calls.
int& safeStaticReference() {
    static int value = 0;
    return value;
}
int main() {
    int marks[] = {78, 91, 84, 88, 91};
    highest(marks, 5) += 2;
    std::cout << "Moderated highest mark: " << highest(marks, 5) << '\n';
    std::cout << "Highest index: " << highestIndex(marks, 5) << '\n';
    safeStaticReference() = 7;
    std::cout << "Static reference example: " << safeStaticReference() << '\n';
}
