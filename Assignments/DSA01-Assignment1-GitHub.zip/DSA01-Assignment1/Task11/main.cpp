#include <iostream>
#include <array>
enum class Zone { Inner, Middle, Outer };
constexpr std::array<long long, 3> FARES = {1000, 2000, 3000};
constexpr long long MIN_BALANCE = 5000;
long long calculateFare(Zone zone, bool peak) {
    auto index = static_cast<std::size_t>(zone);
    if (index >= FARES.size()) return -1;
    long long amount = FARES[index];
    return peak ? amount * 120 / 100 : amount;
}
int main() {
    for (Zone z : {Zone::Inner, Zone::Middle, Zone::Outer})
        std::cout << calculateFare(z, true) << " paise\n";
    std::cout << "Minimum remaining balance: " << MIN_BALANCE << " paise\n";
}
