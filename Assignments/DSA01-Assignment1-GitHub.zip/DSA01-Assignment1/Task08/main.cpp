#include <iomanip>
#include <iostream>
#include <limits>
int main() {
    int hour;
    std::cout << "Enter journey hour (0-23): ";
    while (!(std::cin >> hour) || hour < 0 || hour > 23) {
        std::cout << "Invalid input. Enter an integer from 0 to 23: ";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
    long long farePaise = 3600;
    std::cout << "Accepted hour: " << hour << '\n'
              << "Fare: Rs " << std::fixed << std::setprecision(2)
              << farePaise / 100.0 << '\n';
}
