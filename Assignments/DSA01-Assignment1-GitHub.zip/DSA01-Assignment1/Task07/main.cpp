#include <iostream>
class SmartCard {
    long long balance;
public:
    explicit SmartCard(long long b) : balance(b) {}
    bool canTravel(long long fare) const { return fare >= 0 && balance - fare >= 5000; }
    bool deduct(long long fare) {
        if (!canTravel(fare)) return false;
        balance -= fare; return true;
    }
    long long getBalance() const { return balance; }
};
bool proceduralCanTravel(long long balance, long long fare) {
    return fare >= 0 && balance - fare >= 5000;
}
int main() {
    long long proceduralBalance = 10000, fare = 3000;
    if (proceduralCanTravel(proceduralBalance, fare)) proceduralBalance -= fare;
    std::cout << "Procedural balance: " << proceduralBalance << '\n';
    SmartCard card(10000);
    card.deduct(fare);
    std::cout << "OOP balance: " << card.getBalance() << '\n';
}
