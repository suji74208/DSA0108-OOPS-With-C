#include <iostream>
#include <string>
using namespace std;

class SmartCard {
    long long balancePaise;
public:
    explicit SmartCard(long long balance) : balancePaise(balance) {}
    long long balance() const { return balancePaise; }
    bool canTravel(long long fare) const { return balancePaise - fare >= 5000; }
    bool deduct(long long fare) {
        if (fare < 0 || !canTravel(fare)) return false;
        balancePaise -= fare;
        return true;
    }
};
class Passenger {
    string name;
    bool student, senior;
public:
    Passenger(string n, bool s, bool c) : name(n), student(s), senior(c) {}
    bool hasConcession() const { return student || senior; }
};
class Journey {
public:
    int fromZone, toZone, hour;
    Journey(int f, int t, int h) : fromZone(f), toZone(t), hour(h) {}
    int farthestZone() const { return (fromZone > toZone ? fromZone : toZone); }
};
class FareTable {
public:
    static long long calculate(int zone, int hour, bool concession) {
        const long long fares[] = {1000, 2000, 3000};
        if (zone < 0 || zone > 2 || hour < 0 || hour > 23) return -1;
        long long fare = fares[zone];
        bool peak = (hour >= 8 && hour < 10) || (hour >= 17 && hour < 20);
        if (peak) fare = fare * 120 / 100;
        if (concession) fare = fare * 80 / 100;
        return fare;
    }
};
int main() {
    SmartCard card(10000);
    Passenger p("Student", true, false);
    Journey j(0, 2, 8);
    long long fare = FareTable::calculate(j.farthestZone(), j.hour, p.hasConcession());
    cout << "Fare (paise): " << fare << '\n';
    cout << (card.deduct(fare) ? "Journey allowed" : "Journey denied") << '\n';
    cout << "Balance (paise): " << card.balance() << '\n';
}
