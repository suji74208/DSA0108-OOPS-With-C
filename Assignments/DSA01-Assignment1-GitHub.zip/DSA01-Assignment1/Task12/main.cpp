#include <array>
#include <iostream>
#include <set>
enum class Zone { Inner, Middle, Outer, Airport };
constexpr std::array<long long, 4> FARES = {1000, 2000, 3000, 6000};
class MonthlyPass {
    std::set<Zone> covered;
public:
    MonthlyPass(Zone a, Zone b) : covered{a, b} {}
    bool covers(Zone z) const { return covered.count(z) != 0; }
};
class SmartCard {
    long long balance;
public:
    explicit SmartCard(long long b) : balance(b) {}
    bool pay(long long fare) {
        if (fare < 0 || balance - fare < 5000) return false;
        balance -= fare; return true;
    }
    long long getBalance() const { return balance; }
};
long long calculateFare(Zone z, bool peak, bool weekend) {
    long long amount = FARES.at(static_cast<std::size_t>(z));
    if (weekend) return amount * 90 / 100; // weekend discount replaces peak surcharge
    if (peak) return amount * 120 / 100;
    return amount;
}
int main() {
    SmartCard card(20000);
    MonthlyPass pass(Zone::Inner, Zone::Middle);
    Zone journeys[] = {Zone::Inner, Zone::Airport, Zone::Middle, Zone::Outer};
    for (Zone z : journeys) {
        if (pass.covers(z)) {
            std::cout << "Monthly pass: no fare deducted; ";
        } else {
            long long f = calculateFare(z, true, true);
            std::cout << "Fare " << f << " paise; "
                      << (card.pay(f) ? "paid" : "denied") << "; ";
        }
        std::cout << "balance " << card.getBalance() << " paise\n";
    }
}
