#include <iostream>
#include <vector>
struct Test { int zone; int hour; long long expected; };
long long computeFare(int zone, int hour) {
    const long long base[] = {1000, 2000, 3000};
    if (zone < 0 || zone > 2 || hour < 0 || hour > 23) return -1;
    bool peak = (hour >= 8 && hour < 10) || (hour >= 17 && hour < 20);
    return peak ? base[zone] * 120 / 100 : base[zone];
}
int main() {
    std::vector<Test> tests = {
        {0, 7, 1000}, {0, 8, 1200}, {1, 10, 2000},
        {2, 17, 3600}, {2, 20, 3000}, {3, 9, -1},
        {1, 23, 2000}
    };
    int passed = 0;
    for (const auto& t : tests) {
        long long actual = computeFare(t.zone, t.hour);
        bool ok = actual == t.expected;
        passed += ok;
        std::cout << "zone=" << t.zone << " hour=" << t.hour
                  << " expected=" << t.expected << " actual=" << actual
                  << (ok ? " PASS" : " FAIL") << '\n';
    }
    std::cout << "Passed " << passed << "/" << tests.size() << " tests\n";
}
