#include <climits>
#include <iostream>
#include <string>
int main() {
    bool valid = true;
    char zoneCode = 'O';
    int hour = 8;
    long long farePaise = 3600, balancePaise = 10000, journeys = 3000000;
    double sample = 1.25;
    std::cout << "sizeof(bool)=" << sizeof(valid) << '\n'
              << "sizeof(char)=" << sizeof(zoneCode) << '\n'
              << "sizeof(int)=" << sizeof(hour) << '\n'
              << "sizeof(long long)=" << sizeof(farePaise) << '\n'
              << "sizeof(double)=" << sizeof(sample) << '\n'
              << "INT_MAX=" << INT_MAX << '\n'
              << "Network journeys=" << journeys << '\n'
              << "Fare paise=" << farePaise << ", balance paise=" << balancePaise << '\n';
}
