# DSA01 – Assignment 1: C++ Metro Smart-Card Fare System

**Student name:** [Enter your name]  
**Register number:** [Enter your register number]  
**Course:** Object Oriented Programming with C++  
**Compiler:** g++ (C++17)

## Compile
From the repository root, compile any task with:
```bash
g++ -std=c++17 -Wall -Wextra Task01/main.cpp -o task01
```
Replace `Task01` with the required folder. Run with `./task01` (Windows: `task01.exe`).

## Repository structure
- `Task01`–`Task12`: source code for each task.
- `Report/Assignment_Answers.md`: written answers, explanations, pseudocode, complexity analysis and test evidence.
- `Report/Test_Cases.md`: consolidated test cases and expected results.

## Task results
| Task | Contents |
|---|---|
| 1 | Object-oriented analysis and object model |
| 2 | Tokens, constants and enum class demonstration |
| 3 | Data types, sizes and integer-paise money |
| 4 | Implicit conversions and corrected examples |
| 5 | Operator precedence and predicted output |
| 6 | Switch-based fare calculation and journey processing |
| 7 | Procedural and object-oriented implementations |
| 8 | Safe input and formatted output |
| 9 | Fare implementation and boundary tests |
| 10 | Large-total and numeric-type comparison |
| 11 | Recommended final design |
| 12 | Fourth zone, weekend discount and monthly pass |

## Important
1. Replace the student placeholders before submission.
2. Compile and execute every program on your own computer.
3. Capture your own terminal output screenshots and add them to the corresponding task folder.
4. Record the compiler version from `g++ --version`.
5. Commit each task separately to GitHub. Do not claim measurements or screenshots that you have not personally produced.
