#include <climits>
#include <iomanip>
#include <iostream>
#include <vector>
int main() {
    const long long farePaise = 1234;
    const long long counts[] = {20000, 500000, 3000000};
    for (long long n : counts) {
        long long exactPaise = farePaise * n;
        double rupees = 12.34;
        double doubleTotal = rupees * static_cast<double>(n);
        std::cout << "Journeys: " << n
                  << " integer total paise: " << exactPaise
                  << " integer total Rs: " << std::fixed << std::setprecision(2)
                  << exactPaise / 100.0
                  << " double total Rs: " << doubleTotal << '\n';
    }
    std::cout << "int max: " << INT_MAX << '\n';
}
