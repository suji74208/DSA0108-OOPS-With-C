#include <iostream>
enum class Zone { Inner, Middle, Outer };
constexpr long long INNER_FARE = 1000;
constexpr long long MIDDLE_FARE = 2000;
constexpr long long OUTER_FARE = 3000;
constexpr int PEAK_SURCHARGE_PERCENT = 20;
constexpr long long MIN_BALANCE_PAISE = 5000;
int main() {
    Zone z = Zone::Outer;
    long long fare = (z == Zone::Inner) ? INNER_FARE :
                     (z == Zone::Middle) ? MIDDLE_FARE : OUTER_FARE;
    std::cout << "Fare (paise): " << fare << '\n'
              << "Minimum balance (paise): " << MIN_BALANCE_PAISE << '\n'
              << "Peak surcharge: " << PEAK_SURCHARGE_PERCENT << "%\n";
}
