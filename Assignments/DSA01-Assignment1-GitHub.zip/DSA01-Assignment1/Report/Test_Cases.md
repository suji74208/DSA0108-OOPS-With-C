# Test cases and expected fare values

Peak windows: 08:00–09:59 and 17:00–19:59. Outside these windows is off-peak.

| Zone | Hour | Expected fare | Reason |
|---|---:|---:|---|
| Inner | 07 | Rs 10.00 | off-peak |
| Inner | 08 | Rs 12.00 | peak begins |
| Inner | 10 | Rs 10.00 | peak ends; 10:00 is off-peak |
| Middle | 17 | Rs 24.00 | evening peak begins |
| Outer | 19 | Rs 36.00 | evening peak |
| Outer | 20 | Rs 30.00 | 20:00 is off-peak |
| Unknown zone | 09 | Invalid | zone outside defined range |
| Middle | -1 | Invalid | invalid hour |
| Middle | 24 | Invalid | invalid hour |

## Minimum balance boundary
For a fare of Rs 10.00:
- Starting balance Rs 60.00 -> accepted; remaining balance exactly Rs 50.00.
- Starting balance Rs 59.99 -> denied; remaining balance would be below Rs 50.00.

## Example five-journey hand calculation
Assume a starting balance of Rs 200.00 and no concession:
1. Inner, 07:00 = Rs 10.00; balance Rs 190.00.
2. Middle, 08:00 = Rs 24.00; balance Rs 166.00.
3. Outer, 10:00 = Rs 30.00; balance Rs 136.00.
4. Inner, 17:00 = Rs 12.00; balance Rs 124.00.
5. Outer, 20:00 = Rs 30.00; balance Rs 94.00.

Total charged = Rs 106.00. All five journeys satisfy the Rs 50 minimum balance rule.
