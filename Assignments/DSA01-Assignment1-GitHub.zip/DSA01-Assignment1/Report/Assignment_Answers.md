# Assignment 1 – Written Answers
## City Metro Smart-Card Fare System

> **Student details:** Replace the placeholders in `README.md` and on your report cover page. The assignment asks for personal execution evidence. Run every program yourself and add genuine screenshots; do not present the illustrative calculations below as measurements from your own computer.

## System assumptions used
- Zones are numbered Inner = 0, Middle = 1, Outer = 2; the fare is based on the farthest zone travelled.
- Base fares are Rs 10, Rs 20 and Rs 30.
- Peak hours are 08:00–09:59 and 17:00–19:59. Thus 10:00 and 20:00 are not peak.
- Peak surcharge is 20%. The reference implementation applies an 20% concession after peak surcharge for eligible students/senior citizens; where a formal concession percentage is not specified, 20% is an explicit design assumption and should be confirmed with the faculty.
- At least Rs 50 (5000 paise) must remain after deduction.
- All money is stored as integer paise. Percentage arithmetic is performed in integer arithmetic; the chosen fares divide exactly by 100.

## Task 1 – Understand the problem and identify objects
The main objects are:

| Object | Data | Behaviour / reason |
|---|---|---|
| SmartCard | card ID, balance in paise | recharge, check balance, validate and deduct fare; protects the minimum balance rule |
| Passenger | name/ID, passenger category | identifies student or senior-citizen concession eligibility |
| Journey | source zone, destination zone, time | determines farthest zone and whether the journey is in peak time |
| Zone | zone identity and fare category | represents Inner, Middle and Outer in a type-safe way |
| FareTable | base fares and discount rules | calculates a fare consistently from one central location |

A procedural design would keep balances and fare arrays in separate variables and call free functions such as `calculateFare()` and `deductFare()`. An object-oriented design groups data and operations in classes. Encapsulation keeps the card balance private; abstraction exposes simple operations such as `pay()`; inheritance could define `Passenger` subclasses such as `Student` and `SeniorCitizen`; polymorphism could allow each passenger type to implement its own concession calculation through a virtual function. Inheritance/polymorphism are useful only if passenger categories grow; a simple enum/strategy may be smaller for two categories.

Every valid journey must have a known zone, a valid hour (0–23), a non-negative fare, sufficient funds, and a post-payment balance of at least 5000 paise. Invalid input must not alter the card. The same journey should always produce the same fare under the same rules.

**Alternative and complexity:** Both procedural and OOP implementations calculate a fare and update a card in O(1) time. A balance value needs O(1) space per card in either design. A procedural program may require edits in several functions when a fare rule changes; a class-based design centralises the rule and reduces accidental changes to card state. The algorithmic complexity does not improve merely by using OOP.

## Task 2 – Tokens, keywords, identifiers and constants
The five token groups are: keywords (`class`, `int`, `return`), identifiers (`SmartCard`, `farePaise`, `balance`), constants/literals (`5000`, `20`, `true`), operators (`+`, `-`, `>=`, `&&`) and punctuators (`;`, `{}`, `()`, `,`).

`#define` performs textual substitution and has no C++ type or normal scope. `const` creates a read-only object whose value may be set at run time. `constexpr` requires a compile-time constant expression and is suitable for fixed fares and percentages. Prefer `constexpr` for the fare table because it is typed, scoped and checked by the compiler. `enum class Zone { Inner, Middle, Outer };` is safer than an unscoped enum because enumerators are scoped and do not implicitly convert to integers. Identifiers should start with a letter or underscore, contain letters/digits/underscores, avoid keywords, and use consistent names such as `farePaise` and `MIN_BALANCE_PAISE`.

**Alternative and complexity:** Macros occupy no object storage, and constexpr values often need no run-time storage when compiled as constants. Both approaches have effectively O(1) access and do not meaningfully change execution time. However, macros lack type checking and scope; enum class plus constexpr gives safer compilation and clearer diagnostics. Adding a fourth zone requires extending the enum and fare table/switch in either design.

## Task 3 – Data types and compatibility

| Value | Suggested type | Reason |
|---|---|---|
| Fare and balance | `long long` paise | exact integer money and large totals |
| Peak flag / concession | `bool` | true or false state |
| Zone | `enum class Zone` | named, type-safe choices |
| Hour / zone index | `int` | small whole-number values |
| Daily/network journey count | `long long` | large counts and totals |
| Zone display code | `char` | one character |
| Display-only fractional result | `double` | suitable for non-authoritative display/calculation |
| Inferred local value | `auto` | useful when the initializer makes the type clear |

Use integer paise because decimal floating-point cannot represent every decimal fraction exactly. For example, repeated floating-point addition of Rs 0.10 can produce a value slightly different from the exact decimal total. Integer paise avoids this for currency operations. `sizeof` is implementation-dependent; the Task03 program prints the sizes on the compiler used. Common systems report 1 byte for `char`/`bool`, 4 for `int`, and 8 for `long long`/`double`, but record your actual output. `<climits>` provides `INT_MAX`, `LLONG_MAX` and related limits. Three million journeys at Rs 36 each is Rs 108,000,000 (10,800,000,000 paise), which exceeds a signed 32-bit `int` paise total; `long long` is appropriate.

In mixed expressions, `bool` promotes to an integer, and an integer may convert to `double` if combined with a double. Integer division truncates toward zero before any later conversion. Signed/unsigned mixing can convert a negative signed value to a large unsigned value. Always choose types deliberately and validate ranges.

**Alternative and complexity:** `double` and `long long` commonly both occupy 8 bytes and each addition is O(1). But double arithmetic can accumulate representation/rounding error; integer paise remains exact until integer overflow. Measure the error by running repeated additions for the requested journey counts on the target compiler; do not claim a specific measured error without executing it.

## Task 4 – Control implicit conversions
In `double c = a / b`, both operands are integers, so `7 / 2` is evaluated as integer division and gives 3; only then is 3 converted to 3.0. In `static_cast<double>(a) / b`, division is floating-point and gives 3.5. `'A' + 2` promotes the character to int, computes 67, then converts to `char` (`C` in the basic execution character set). Printing `ch + 1` prints the integer value 68. Assigning 5 to bool converts it to `true`; default stream formatting prints `1`, while `boolalpha` prints `true`. In `s < u`, `s` is converted to unsigned; -1 becomes a large unsigned value, so the comparison is false and the program prints `s >= u`.

**Exact predicted output:**
```text
3 3.5
C 68
1 true
s >= u
```

Brace initialization such as `int x{3.7};` is rejected because it would narrow. `static_cast<double>(a)` documents an intentional conversion. Explicit casts do not normally change run time or storage; they make intent visible. Brace initialization catches many narrowing mistakes at compile time, while runtime validation is still required for user input and ranges.

## Task 5 – Expressions and precedence
Peak condition:
```cpp
(hour >= 8 && hour < 10) || (hour >= 17 && hour < 20)
```
The `&&` operators are evaluated before `||`; parentheses make the two time windows clear. The surcharge can be calculated as `farePaise = farePaise * 120 / 100;`. Apply concession as a separately documented rule. `?:` selects one of two values; compound assignment such as `+=` updates its left operand. Post-increment returns the old value; pre-increment increments first. Avoid `i = i++`, whose behaviour is not a safe way to express an increment and can be undefined/unsequenced depending on the language version/context. Integer division truncates toward zero; remainder has the sign of the dividend (for example, `-10 / 3 == -3` and `-10 % 3 == -1`).

**Exact predicted output:**
```text
11 16
9 6 4
6 4
3 1 -3 -1
18
```

Explanation: multiplication binds more tightly than addition (5 + 3×2 = 11); parentheses force (5+3)×2 = 16. `x++` contributes 5 and then x becomes 6; `++y` changes y from 3 to 4 and contributes 4, so z=9. The conditional returns max(6,4)=6; `%` and `*` are left associative, so `(6 % 4) * 2 = 4`. Integer division/remainder give 3, 1, -3, -1. The loop visits i=0,3,6,9, whose sum is 18.

**Alternative and complexity:** A `bool peak[24]` lookup takes O(1), as does the range expression. It uses approximately 24 bool elements (the actual `sizeof` can be checked), in exchange for a simple indexed lookup. The table must be updated carefully if peak windows change.

## Task 6 – Control structures and pseudocode
Use `switch` for a finite zone selection, `if/else` for validation and eligibility, and `?:` only for a short value choice. A counted set of trips is naturally processed with a range-based `for`; `while` is suitable when input continues until a sentinel. Use `continue` to skip an invalid journey and `break` to leave a loop or switch. A switch with no matching case and no default executes no branch; include `default` to reject unknown values.

**Pseudocode**
```text
ALGORITHM CalculateJourneyFare
INPUT zone, hour, balance
IF zone is not a recognised zone OR hour < 0 OR hour > 23 THEN
    OUTPUT "Invalid journey"; STOP
END IF
SELECT zone
    Inner: baseFare <- 1000
    Middle: baseFare <- 2000
    Outer: baseFare <- 3000
END SELECT
peak <- (8 <= hour AND hour < 10) OR (17 <= hour AND hour < 20)
IF peak THEN fare <- baseFare * 120 / 100
ELSE fare <- baseFare
END IF
IF balance - fare >= 5000 THEN
    balance <- balance - fare
    OUTPUT fare and balance
ELSE OUTPUT "Denied"
END IF
END ALGORITHM
```

The Task06 program implements the switch and minimum-balance check. Its expected output for the supplied three trips is:
```text
Fare Rs 10.00  balance Rs 90
Fare Rs 36.00  balance Rs 54
Denied (low balance)  balance Rs 54
```
The 10:00 and 20:00 boundary times are off-peak under the half-open intervals. A fare array indexed by zone also gives O(1) access; the array uses storage for three `long long` values. A fourth zone requires extending the enum, array and validation; a switch requires adding another case. A table is convenient when zones are data-driven.

## Task 7 – Procedural versus object-oriented
A procedural solution stores `balance` in a variable and calls `proceduralCanTravel(balance, fare)` before subtracting. An OOP solution stores the balance as a private member of `SmartCard` and exposes `canTravel()` and `deduct()`. The class checks the minimum balance before changing its state, so callers cannot directly set an invalid balance. If the minimum changes, a central constant or class rule is updated. Both designs have O(1) time per validation/deduction and O(1) balance storage per card. A public balance member would use the same time and space but any code could assign a negative or below-minimum value, breaking the invariant.

Task07 prints both balances to demonstrate equivalent successful deductions; the class version protects the data better.

## Task 8 – Safe input and output
`cin >> value` sets the stream failure state when the user enters letters for an integer. Check the extraction result, call `cin.clear()` to reset the state, and use `cin.ignore(numeric_limits<streamsize>::max(), '\\n')` to discard the invalid line. Use `<iomanip>` with `fixed` and `setprecision(2)` for rupees, or format integer paise as rupees and two digits of paise. A report should show journey number, zone, time, base fare, surcharge/discount, amount charged and remaining balance.

The Task08 program repeatedly requests a valid hour and demonstrates formatted money output. With `getline`, read a line and convert it with `stoi` inside `try/catch`; conversion takes O(L) time for a line of length L and needs O(L) buffer space. Direct `cin >>` avoids an explicit line buffer but requires careful stream recovery. `getline` plus `stoi` makes whole-line validation and trailing-character checks easier.

## Task 9 – Implementation and tests
The Task09 program runs a table-driven set of tests and reports expected and actual fares. Its table covers off-peak, peak, the 10:00 and 20:00 boundaries, and an invalid zone. Add tests for 08:00, 17:00, 23:00, invalid hours, a balance leaving exactly Rs 50, and a balance leaving less than Rs 50. The key boundary rule is `balance - fare >= 5000`; equality must be accepted. A negative recharge must be rejected before modifying the balance. Five journey totals should be independently calculated in paise and compared with the program output.

A loop over t test cases takes O(t) time and the stored test table takes O(t) space. Adding a new boundary case is a single new table row and is less error-prone than duplicating test code.

## Task 10 – Expected versus executed totals
For a constant fare of Rs 12.34, exact integer-paise totals are:

| Journeys | Total paise | Total rupees |
|---:|---:|---:|
| 20,000 | 24,680,000 | Rs 246,800.00 |
| 500,000 | 617,000,000 | Rs 6,170,000.00 |
| 3,000,000 | 3,702,000,000 | Rs 37,020,000.00 |

These values exceed a signed 32-bit int range when represented in paise. A `long long` safely holds these example totals. `double` has a much larger range but cannot represent all decimal fractions exactly; the displayed total may be rounded. The Task10 program compares integer-paise and double-rupee calculations. Run it with your compiler and record the exact output and any warnings from `-Wall -Wextra`. Do not invent warning messages: they depend on the code/compiler. Each addition is O(1); int and long long are typically 4 and 8 bytes, while double is typically 8 bytes.

## Task 11 – Final recommendation
Use `enum class Zone`, `constexpr` fare constants or a validated fare table, `long long` paise for all money, private SmartCard balance, and dedicated fare calculation/validation functions. Keep the peak interval in one function and ensure the minimum-balance check is centralised. A fare revision should update the single fare configuration and its tests, not scattered literals. This design is suitable for millions of journeys per day because each journey's fare and balance update is O(1), and aggregate totals use `long long`. Limitations include hard-coded fares, a simple concession model, and no persistence/concurrency handling. A configuration file allows changes without recompilation but adds startup parsing, validation and error handling; reading z entries costs O(z) time and O(z) storage. Compiled constants avoid file errors but require rebuilding/redeploying for a change.

## Task 12 – Day-4 design challenge
**Decision: modify the design.** Add `Airport` to `enum class Zone` and add Rs 60 (6000 paise) to the fare table. Replace a fixed three-element switch with a four-element fare table indexed only after validating the zone index. Add a `MonthlyPass` class containing the two selected zones; when a journey's zone is covered, no fare is deducted. For a non-covered zone, apply the weekend discount of 10% instead of the peak surcharge; the two rules must not combine. On weekdays, apply the 20% peak surcharge in peak hours.

Worked examples: Airport off-peak weekday fare = Rs 60.00; Airport peak weekday fare = Rs 72.00; Airport weekend fare = Rs 54.00 whether or not the clock is in peak time, because weekend discount replaces (does not combine with) the peak surcharge. A journey in either of the two monthly-pass zones costs Rs 0 for the pass holder. The SmartCard minimum-balance rule still applies to any fare actually deducted; pass-covered journeys do not deduct stored value.

The Task12 code demonstrates a four-zone table, a two-zone pass and the non-combining weekend rule. The design should be tested with every zone, weekend/weekday, peak/off-peak, both pass zones, a non-covered zone, and balances at Rs 50 exactly and below Rs 50. The table is easier to extend than a long switch, while the separate `MonthlyPass` class keeps pass eligibility distinct from fare arithmetic. The implementation is O(1) for fare lookup and pass membership for the two-zone set in practical constant-sized use; the set has small additional storage. For a larger network, a boolean/vector or hash-based coverage structure can be selected.

---

## Submission checklist
- [ ] Replace student name and register number.
- [ ] Run `g++ --version` and record the actual compiler version.
- [ ] Compile and execute all 12 programs.
- [ ] Save terminal screenshots in each task folder.
- [ ] Add the exact commands and observed outputs to the report.
- [ ] Add a UML class diagram and the required five-journey hand calculation.
- [ ] Commit each task separately and submit the repository URL.
