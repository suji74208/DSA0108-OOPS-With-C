#include <chrono>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
class Time {
    int seconds;
public:
    explicit Time(int s = 0) : seconds(s) {}
    Time& operator++() { ++seconds; return *this; }
    Time operator++(int) { Time old(*this); ++seconds; return old; }
    bool operator==(const Time& other) const { return seconds == other.seconds; }
    bool operator<(const Time& other) const { return seconds < other.seconds; }
    int value() const { return seconds; }
};
class Playlist {
    std::vector<std::string> tracks;
public:
    Playlist(std::initializer_list<std::string> items) : tracks(items) {}
    std::string& operator[](int i) {
        if (i < 0 || i >= static_cast<int>(tracks.size())) throw std::out_of_range("track index");
        return tracks[static_cast<std::size_t>(i)];
    }
    const std::string& operator[](int i) const {
        if (i < 0 || i >= static_cast<int>(tracks.size())) throw std::out_of_range("track index");
        return tracks[static_cast<std::size_t>(i)];
    }
    int size() const { return static_cast<int>(tracks.size()); }
};
int main() {
    Time t(5);
    Time a = t++;
    Time b = ++t;
    std::cout << a.value() << ' ' << b.value() << ' ' << t.value() << '\n';
    Time end(3600), next(3601);
    std::cout << std::boolalpha << (end < next) << ' ' << (end == next) << '\n';
    Playlist list{"Intro", "Song A", "Song B"};
    std::cout << list[1] << '\n';
    for (int bad : {-1, list.size()}) {
        try { std::cout << list[bad] << '\n'; }
        catch (const std::out_of_range& e) { std::cout << "Range error: " << e.what() << '\n'; }
    }
    volatile int sink = 0;
    constexpr int N = 10000000;
    auto s1 = std::chrono::steady_clock::now();
    Time pre;
    for (int i = 0; i < N; ++i) ++pre;
    auto s2 = std::chrono::steady_clock::now();
    Time post;
    for (int i = 0; i < N; ++i) sink += (post++).value();
    auto s3 = std::chrono::steady_clock::now();
    std::chrono::duration<double, std::milli> preMs = s2 - s1, postMs = s3 - s2;
    std::cout << "prefix ms: " << preMs.count() << ", postfix ms: " << postMs.count()
              << " (sink " << sink << ")\n";
}
