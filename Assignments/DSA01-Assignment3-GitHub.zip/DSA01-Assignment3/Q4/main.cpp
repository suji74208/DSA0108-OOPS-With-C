#include <iomanip>
#include <iostream>
class Money {
    long long paise;
public:
    Money(long long rupees = 0, int p = 0) : paise(rupees * 100 + p) {}
    explicit Money(long long totalPaise, bool raw) : paise(raw ? totalPaise : totalPaise * 100) {}
    Money operator+(const Money& other) const { return Money(paise + other.paise, true); }
    Money operator-(const Money& other) const { return Money(paise - other.paise, true); }
    Money& operator+=(const Money& other) { paise += other.paise; return *this; }
    bool operator==(const Money& other) const { return paise == other.paise; }
    bool operator<(const Money& other) const { return paise < other.paise; }
    friend std::ostream& operator<<(std::ostream& os, const Money& m) {
        long long absValue = m.paise < 0 ? -m.paise : m.paise;
        if (m.paise < 0) os << "-";
        return os << "Rs " << absValue / 100 << '.' << std::setw(2)
                  << std::setfill('0') << absValue % 100 << std::setfill(' ');
    }
};
int main() {
    Money a(120, 75), b(79, 25);
    Money c = a + b;
    std::cout << c << '\n' << std::boolalpha << (c == Money(200)) << '\n';
    Money carry(0, 75), half(0, 50);
    std::cout << "Carry test: " << carry + half << '\n';
    std::cout << "Negative subtraction: " << Money(1) - Money(2) << '\n';
    Money total; total += a; total += b;
    std::cout << "Bill total: " << total << '\n';
}
