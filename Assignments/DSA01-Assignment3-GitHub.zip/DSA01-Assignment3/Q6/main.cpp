#include <cstring>
#include <iostream>
#include <string>
class Text {
    char* data;
    static int copies;
public:
    explicit Text(const char* s = "") : data(new char[std::strlen(s) + 1]) {
        std::strcpy(data, s);
    }
    Text(const Text& other) : data(new char[std::strlen(other.data) + 1]) {
        std::strcpy(data, other.data); ++copies;
    }
    Text& operator=(const Text& other) {
        if (this != &other) {
            char* fresh = new char[std::strlen(other.data) + 1];
            std::strcpy(fresh, other.data);
            delete[] data;
            data = fresh;
        }
        return *this;
    }
    ~Text() { delete[] data; }
    Text operator+(const Text& other) const {
        std::size_t n = std::strlen(data) + std::strlen(other.data);
        char* joined = new char[n + 1];
        std::strcpy(joined, data);
        std::strcat(joined, other.data);
        Text result(joined);
        delete[] joined;
        return result;
    }
    bool operator==(const Text& other) const { return std::strcmp(data, other.data) == 0; }
    bool operator!=(const Text& other) const { return !(*this == other); }
    friend std::ostream& operator<<(std::ostream& os, const Text& t) { return os << t.data; }
    static int copyCount() { return copies; }
};
int Text::copies = 0;
int main() {
    Text a("Hello"), b(" "), c("World");
    Text combined = a + b + c;
    std::cout << combined << '\n';
    Text empty("");
    Text longText("A longer SMS message for testing dynamic allocation.");
    Text assigned("temporary");
    assigned = longText;
    assigned = assigned;
    std::cout << "Empty=[" << empty << "] self-assignment=[" << assigned << "]\n";
    std::cout << "Equal? " << std::boolalpha << (a == Text("Hello"))
              << " copies=" << Text::copyCount() << '\n';

    constexpr int N = 100000;
    auto s1 = std::chrono::steady_clock::now();
    std::string standard;
    for (int i = 0; i < N; ++i) standard += 'x';
    auto s2 = std::chrono::steady_clock::now();
    std::chrono::duration<double, std::milli> ms = s2 - s1;
    std::cout << "std::string 100k append ms: " << ms.count()
              << " length=" << standard.size() << '\n';
}
