# DSA01 – Assignment 3 (CO3): Constructors, Destructors and Operator Overloading

Student name: [Enter name]  
Register number: [Enter register number]  
Compiler: g++ [enter version]  
Standard: C++17

## Compile and run
Example:
```bash
g++ -std=c++17 -Wall -Wextra Q1/main.cpp -o q1
./q1
```
Repeat for Q2–Q7. Sanitizer example:
```bash
g++ -std=c++17 -Wall -Wextra -fsanitize=address -fno-omit-frame-pointer Q2/main.cpp -o q2_asan
./q2_asan
```

## Folder contents
- Q1: constructors and constructor overloading
- Q2: deep copy, copy assignment and destructor
- Q3: dynamic 2D seat map and object lifetime
- Q4: Money arithmetic and stream operators
- Q5: prefix/postfix increment, comparisons and checked subscript
- Q6: dynamically allocated Text class and operator rules
- Q7: Complex-number class and AC impedance calculations
- Report: written answers, output predictions, complexity analysis and evidence checklist

## Submission checklist
- [ ] Replace student details and add GitHub link.
- [ ] Compile and run every program on your machine.
- [ ] Save genuine output screenshots in each Q folder.
- [ ] Run Q2, Q3 and Q6 with AddressSanitizer.
- [ ] Measure Q2 copy timings, Q3 memory sizes, Q4 double-vs-paise timings, Q5 increment/access timings at -O0 and -O2, and Q6 concatenation timings.
- [ ] Commit each question progressively (at least one commit per question).
- [ ] Do not submit invented screenshots, sanitizer reports or timings.
