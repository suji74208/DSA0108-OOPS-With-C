# Assignment 3 – Test Evidence Record

Fill with actual results from your computer.

| Question | Evidence to capture | Actual result / measurement | Screenshot or log |
|---|---|---|---|
| Q1 | all constructors; negative copies; removed default constructor compile error; -Wreorder | [Fill] | [Fill] |
| Q2 | deep copy output; shallow-copy ASan report; self-assignment | [Fill] | [Fill] |
| Q2 | copy time for 10, 1,000, 100,000 medicines | [Fill] | [Fill] |
| Q3 | constructor/destructor order; zero-row event; ASan | [Fill] | [Fill] |
| Q3 | memory for 10x20, 100x200, 1000x2000 | [Fill] | [Fill] |
| Q4 | carry, negative subtraction, stream output | [Fill] | [Fill] |
| Q4 | 1,000,000 paise vs double additions | [Fill] | [Fill] |
| Q5 | prefix/postfix and out-of-range tests | [Fill] | [Fill] |
| Q5 | 10M prefix/postfix at -O0 and -O2 | [Fill] | [Fill] |
| Q6 | long/empty text; self-assignment; copy count; ASan | [Fill] | [Fill] |
| Q6 | Text vs std::string 100,000 concatenations | [Fill] | [Fill] |
| Q7 | hand-checked RLC series/parallel values; zero division | [Fill] | [Fill] |

Compiler version: [Fill]  
OS / CPU: [Fill]  
Exact compile commands: [Fill]  
GitHub repository URL: [Fill]
