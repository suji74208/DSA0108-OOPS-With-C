# Assignment 3 – Written Answers and Design Analysis

Student: [Name]  
Register number: [Register number]  
GitHub repository: [Paste URL]

**Evidence reminder:** Write predictions before execution. Run all code yourself and insert actual screenshots, compiler messages, sanitizer reports and timings. Reference outputs below are analytical expectations, not claims that your machine produced them.

## Q1 – Constructors and Constructor Overloading (6)

The `Book` class supplies a default constructor, title-only constructor, title-and-copy-count constructor and full constructor. Delegating constructors centralise initialisation and validation. Negative copy counts throw `std::invalid_argument`.

The compiler supplies an implicit default constructor only when no user-declared constructor prevents it. Once a constructor is declared, a default constructor is not automatically added. Member initializer lists directly initialise members and are required for references, const members and members without default constructors. Members initialise in declaration order, not initializer-list order.

State examples:
- default: `Untitled / Unknown / 0`
- donated title: `C++ Primer / Donated / 1`
- full: `The C++ Programming Language / Bjarne Stroustrup / 3`

Removing the default constructor makes `Book shelf[3];` fail because each array element needs a default constructor. `-Wreorder` appears when initializer-list order differs from declaration order. `explicit` prevents unintended implicit conversions, especially single-argument constructors. Example: without explicit, `Book b = "C++ Primer";` may compile; with explicit, use direct initialisation `Book b("C++ Primer");`.

Alternative: one constructor with defaults is concise, but overloads communicate intent more clearly. Object construction is O(1) time and O(1) object storage for fixed-size fields in either design. Centralised validation avoids inconsistent checks.

## Q2 – Copy Constructors: Shallow and Deep Copies (7)

The copy constructor allocates a new array and copies each string. Copy assignment first checks `this != &other`, builds a new array, copies all elements, then deletes the old array and adopts the new one. The destructor uses `delete[]`.

Expected completed-program output:
```text
Ibuprofen ORS | Paracetamol Cetirizine | Paracetamol ORS
```
Each object owns an independent array. A shallow copy copies only the pointer; both objects then point to the same allocation. Modifying one changes what the other observes, and both destructors attempt to free the same allocation, causing double-free/undefined behaviour.

Rule of Three: if a class needs a user-defined destructor, copy constructor or copy assignment operator for resource ownership, it usually needs all three. Copy constructor situations include initialising from another object, passing by value and returning by value (subject to elision). `const T&` avoids a copy; by-value makes a deep copy here.

Deep copy time and additional storage are O(n) for n medicine names. Shallow pointer copying is O(1) but unsafe for unique ownership. `std::vector<std::string>` follows Rule of Zero and gives independent value copies without manually writing these three functions. Run ASan on the correct implementation and a separate intentionally shallow-copy demonstration; record the actual sanitizer diagnostic rather than inventing it.

## Q3 – Dynamic Constructors and Destructors (7)

The auditorium allocates an array of row pointers and then one character array per row. The destructor deletes each row with `delete[]`, then deletes the row-pointer array with `delete[]`. A forgotten delete leaks memory. Using scalar `delete` for an array allocation is undefined behaviour.

Local and block objects are destroyed automatically in reverse construction order when their scope ends. A heap object remains alive until `delete` is called. A destructor has no parameters and no return type; it cannot be overloaded because object destruction has one fixed operation.

For r rows and c seats, the row-pointer layout uses r+1 allocations (one pointer array plus r row arrays); a contiguous flat allocation uses one allocation and index `r * columns + c`. Access remains O(1). Pointer overhead is O(r). Total seat storage is O(rc). Zero rows should allocate no row-pointer array.

RAII ties cleanup to object lifetime, so early returns and exceptions still invoke destructors for fully constructed automatic objects. Run ASan with a deliberately missing delete only as a separate controlled test, then with the correct implementation.

### Logger prediction
```text
+A +B -B copyAc use -Ac +P -P end -A
```
`a` is constructed first. `b` is constructed and destroyed at the end of the inner block. Passing `a` by value copies it (`Ac`); the parameter is destroyed after `use` returns. The heap Logger `P` is destroyed by `delete`. Finally `a` is destroyed at the end of main.

## Q4 – Arithmetic and Stream Operators (7)

`Money` stores integer paise to avoid floating-point rounding. `+` returns a new value; `+=` mutates the left operand and returns `*this` by reference to support chaining. `==` compares paise. `<<` is a non-member because the left operand is an `ostream`; it is a friend only if private access is required. The expression `a + b` maps to `a.operator+(b)` for a member overload.

The completed program should print:
```text
Rs 200.00
true
Carry test: Rs 1.25
Negative subtraction: Rs -1.00
Bill total: Rs 200.00
```
A `double` representation can accumulate binary rounding error; integer paise is exact for whole paise. Addition/subtraction/comparison are O(1), with O(1) storage. Multiplying one Money by another is usually not meaningful; multiplication by a quantity or rate is more appropriate. Friend/non-member arithmetic can support symmetric expressions such as `100 + money`; member arithmetic naturally supports `money + 100` only if conversion is permitted.

## Q5 – Increment, Comparison and Subscript (6)

Prefix `++x` calls `operator++()` and returns a reference to the updated object. Postfix `x++` calls `operator++(int)`; the dummy int distinguishes it and the operator returns the old value by copy.

Counter prediction:
```text
5 7 7
```
Starting at 5, `a=c++` stores 5 and advances c to 6; `b=++c` advances c to 7 and stores 7.

A non-const `operator[]` returns a mutable reference; the const overload returns a const reference. Both validate bounds and throw `std::out_of_range`. Prefix avoids creating the old-value copy, so it is often preferred for class types when the old value is not needed. Time per increment/access is O(1); postfix creates an extra object copy (O(1) for this small Time class).

Compile at both optimisation levels and record measurements:
```bash
g++ -std=c++17 -O0 Q5/main.cpp -o q5_O0 && ./q5_O0
g++ -std=c++17 -O2 Q5/main.cpp -o q5_O2 && ./q5_O2
```
The sample Time stores total seconds, so it avoids minute/hour rollover bugs; display formatting can convert to hh:mm:ss.

## Q6 – Rules of Operator Overloading (7)

Operators that cannot be overloaded include `::`, `.`, `.*`, `?:` and `sizeof`. An overload cannot change precedence, arity or associativity; at least one operand must be a user-defined type. Assignment `operator=` must be a member. Stream insertion is normally a non-member, often a friend if it needs private data.

The `Text` class owns a null-terminated dynamic character array. It implements constructor, deep-copy constructor, copy assignment, destructor, concatenation, equality and output. Self-assignment is guarded. Run with:
```bash
g++ -std=c++17 -fsanitize=address -fno-omit-frame-pointer Q6/main.cpp -o q6_asan
./q6_asan
```
For `a+b+c`, the left-associative expression first creates the combined `a+b` result, then concatenates `c`. Character copying is proportional to the combined lengths; intermediate storage is created. With lengths n1,n2,n3, a straightforward two-stage `+` copies O(n1+n2) then O(n1+n2+n3) characters and creates a temporary of size O(n1+n2). `std::string` handles ownership and capacity management and is normally preferred. A custom Text class is justified for specialised storage, ABI or educational/embedded requirements.

## Q7 – Complex Number from First Principles (10)

Data: real and imaginary components. Constructors: zero/default, real-only, and real-plus-imaginary. Operations:
- addition: `(a+bi)+(c+di)=(a+c)+(b+d)i`
- subtraction: `(a-c)+(b-d)i`
- multiplication: `(ac-bd)+(ad+bc)i`
- division: `((ac+bd)/(c²+d²))+((bc-ad)/(c²+d²))i`
- magnitude: `sqrt(a²+b²)`

Division checks a zero denominator and throws `std::domain_error`. `<<` is a non-member friend for rectangular output. Each operation is O(1) time and O(1) space. `std::complex<double>` provides tested arithmetic and is preferable for production unless custom validation or representation is required. Floating-point equality is an important limitation; engineering software should normally compare with a tolerance.

The program computes series RLC impedance as `R + jωL - j/(ωC)` and a parallel R-L impedance using `(Z1*Z2)/(Z1+Z2)`. Verify the printed values with hand calculations using the same frequency and component values.

## Final evidence checklist

- [ ] Q1 all constructors, negative count and compiler error/warning evidence
- [ ] Q2 correct deep copy and separate shallow-copy sanitizer demonstration
- [ ] Q3 stack, block and heap lifetime order; ASan; allocation measurements
- [ ] Q4 paise carry, negative subtraction and double comparison measurements
- [ ] Q5 prefix/postfix values, invalid indices, rollover and -O0/-O2 timings
- [ ] Q6 long/empty strings, self-assignment, copy count and ASan
- [ ] Q7 hand calculations, zero division and std::complex comparison
- [ ] Genuine screenshots and one progressive Git commit per question
