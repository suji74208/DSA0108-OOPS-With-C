#include <cmath>
#include <iostream>
#include <stdexcept>
#include <complex>
class Complex {
    double re, im;
public:
    Complex() : re(0), im(0) {}
    Complex(double real) : re(real), im(0) {}
    Complex(double real, double imag) : re(real), im(imag) {}
    Complex operator+(const Complex& z) const { return {re + z.re, im + z.im}; }
    Complex operator-(const Complex& z) const { return {re - z.re, im - z.im}; }
    Complex operator*(const Complex& z) const {
        return {re * z.re - im * z.im, re * z.im + im * z.re};
    }
    Complex operator/(const Complex& z) const {
        double den = z.re * z.re + z.im * z.im;
        if (den == 0.0) throw std::domain_error("division by zero impedance");
        return {(re * z.re + im * z.im) / den,
                (im * z.re - re * z.im) / den};
    }
    bool operator==(const Complex& z) const { return re == z.re && im == z.im; }
    double magnitude() const { return std::sqrt(re * re + im * im); }
    friend std::ostream& operator<<(std::ostream& os, const Complex& z) {
        os << z.re << (z.im < 0 ? " - j" : " + j") << std::abs(z.im);
        return os;
    }
};
int main() {
    constexpr double pi = 3.141592653589793;
    const double f = 50.0, w = 2.0 * pi * f, L = 0.1, C = 100e-6;
    Complex resistor(10.0);
    Complex inductor(0.0, w * L);
    Complex capacitor(0.0, -1.0 / (w * C));
    Complex series = resistor + inductor + capacitor;
    Complex parallel;
    try {
        parallel = (resistor * inductor) / (resistor + inductor);
        std::cout << "R parallel L: " << parallel
                  << " | magnitude=" << parallel.magnitude() << '\n';
    } catch (const std::domain_error& e) {
        std::cout << e.what() << '\n';
    }
    std::cout << "Series RLC: " << series << " | magnitude=" << series.magnitude() << '\n';
    try { Complex invalid = resistor / Complex(); (void)invalid; }
    catch (const std::domain_error& e) { std::cout << "Safe error: " << e.what() << '\n'; }

    std::complex<double> standardR(10.0, 0.0), standardL(0.0, w * L);
    auto standardParallel = standardR * standardL / (standardR + standardL);
    std::cout << "std::complex R parallel L magnitude: " << std::abs(standardParallel) << '\n';
}
