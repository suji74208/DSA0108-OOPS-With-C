#include <chrono>
#include <iostream>
#include <string>
#include <utility>
class Prescription {
    int n;
    std::string* medicines;
public:
    explicit Prescription(int count)
        : n(count), medicines(count > 0 ? new std::string[count] : nullptr) {}
    Prescription(const Prescription& other)
        : n(other.n), medicines(n > 0 ? new std::string[n] : nullptr) {
        for (int i = 0; i < n; ++i) medicines[i] = other.medicines[i];
    }
    Prescription& operator=(const Prescription& other) {
        if (this != &other) {
            std::string* fresh = other.n > 0 ? new std::string[other.n] : nullptr;
            for (int i = 0; i < other.n; ++i) fresh[i] = other.medicines[i];
            delete[] medicines;
            medicines = fresh;
            n = other.n;
        }
        return *this;
    }
    ~Prescription() { delete[] medicines; }
    void set(int i, const std::string& m) { if (i >= 0 && i < n) medicines[i] = m; }
    std::string get(int i) const { return (i >= 0 && i < n) ? medicines[i] : ""; }
    int size() const { return n; }
};
void inspectByValue(Prescription p) { (void)p.get(0); }
void inspectByConstReference(const Prescription& p) { (void)p.get(0); }
int main() {
    Prescription p(2);
    p.set(0, "Paracetamol"); p.set(1, "ORS");
    Prescription q = p;
    q.set(1, "Cetirizine");
    Prescription r(1);
    r = p;
    p.set(0, "Ibuprofen");
    std::cout << p.get(0) << ' ' << p.get(1) << " | "
              << q.get(0) << ' ' << q.get(1) << " | "
              << r.get(0) << ' ' << r.get(1) << '\n';
    p = p; // self-assignment test
    inspectByValue(p);
    inspectByConstReference(p);
    std::cout << "Self-assignment safe: " << p.get(0) << '\n';

    for (int count : {10, 1000, 100000}) {
        Prescription sample(count);
        auto start = std::chrono::steady_clock::now();
        for (int i = 0; i < 100; ++i) inspectByValue(sample);
        auto finish = std::chrono::steady_clock::now();
        std::chrono::duration<double, std::milli> ms = finish - start;
        std::cout << "100 value copies, n=" << count << ": " << ms.count() << " ms\n";
    }
}
