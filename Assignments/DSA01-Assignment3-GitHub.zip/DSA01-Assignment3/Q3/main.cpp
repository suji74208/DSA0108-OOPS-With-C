#include <iostream>
#include <string>
class Auditorium {
    int rows, cols, booked;
    char** seats;
    std::string name;
public:
    Auditorium(std::string eventName, int r, int c)
        : rows(r > 0 ? r : 0), cols(c > 0 ? c : 0), booked(0),
          seats(rows ? new char*[rows] : nullptr), name(std::move(eventName)) {
        for (int i = 0; i < rows; ++i) {
            seats[i] = new char[cols];
            for (int j = 0; j < cols; ++j) seats[i][j] = 'O';
        }
        std::cout << "Open " << name << " (" << rows << "x" << cols << ")\n";
    }
    bool book(int r, int c) {
        if (r < 0 || r >= rows || c < 0 || c >= cols || seats[r][c] == 'X') return false;
        seats[r][c] = 'X'; ++booked; return true;
    }
    bool cancel(int r, int c) {
        if (r < 0 || r >= rows || c < 0 || c >= cols || seats[r][c] != 'X') return false;
        seats[r][c] = 'O'; --booked; return true;
    }
    ~Auditorium() {
        for (int i = 0; i < rows; ++i) delete[] seats[i];
        delete[] seats;
        std::cout << "Close " << name << " | booked=" << booked << '\n';
    }
};
int main() {
    Auditorium stackEvent("StackEvent", 2, 3);
    stackEvent.book(0, 0); stackEvent.book(1, 2); stackEvent.cancel(0, 0);
    {
        Auditorium blockEvent("BlockEvent", 1, 2);
        blockEvent.book(0, 1);
    }
    Auditorium* heapEvent = new Auditorium("HeapEvent", 2, 2);
    heapEvent->book(1, 1);
    delete heapEvent;
    Auditorium zeroRows("ZeroRows", 0, 5);
}
